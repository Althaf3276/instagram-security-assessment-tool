#!/usr/bin/env python3
"""
Setup verification script for Instagram Account Security Assessment Tool
This script checks if the environment is properly set up to run the tool
"""

import sys
import os
import subprocess
import platform
from pathlib import Path

def check_python_version():
    """Check if Python version meets requirements"""
    print("Checking Python version...", end=" ")
    if sys.version_info >= (3, 7):
        print(f"✓ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} detected")
        return True
    else:
        print(f"✗ Python 3.7+ required, found {sys.version}")
        return False

def check_pip():
    """Check if pip is available"""
    print("Checking pip availability...", end=" ")
    try:
        import pip
        print(f"✓ pip {pip.__version__} available")
        return True
    except ImportError:
        print("✗ pip not available")
        return False

def check_required_packages():
    """Check if required packages are installed"""
    print("Checking required packages...", end=" ")
    required_packages = ['requests', 'urllib3', 'certifi', 'charset-normalizer', 'idna', 'python-dateutil', 'typing-extensions']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"✗ Missing packages: {', '.join(missing_packages)}")
        print("  Run: pip install -r requirements.txt")
        return False
    else:
        print("✓ All required packages available")
        return True

def check_virtual_environment():
    """Check if running in a virtual environment"""
    print("Checking virtual environment...", end=" ")
    if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        print("✓ Running in virtual environment")
        return True
    else:
        print("? Not running in virtual environment (recommended but not required)")
        return True

def check_directories():
    """Check if required directories exist"""
    print("Checking required directories...", end=" ")
    required_dirs = ['reports', 'modules']
    missing_dirs = []
    
    for directory in required_dirs:
        if not os.path.exists(directory):
            missing_dirs.append(directory)
    
    if missing_dirs:
        print(f"✗ Missing directories: {', '.join(missing_dirs)}")
        return False
    else:
        print("✓ All required directories exist")
        return True

def test_instagram_fetch():
    """Test fetching Instagram profile data (basic connectivity test)"""
    print("Testing Instagram connectivity...", end=" ")
    try:
        import requests
        # Try to fetch Instagram's main page to test connectivity
        response = requests.get('https://www.instagram.com/', timeout=10)
        if response.status_code in [200, 404, 403]:  # 404/403 are normal for main page
            print("✓ Instagram connectivity OK")
            return True
        else:
            print(f"? Unexpected status code: {response.status_code}")
            return True  # Not necessarily an error
    except requests.exceptions.RequestException as e:
        print(f"? Connectivity test failed: {e}")
        return True  # This may be due to network issues, not necessarily a setup problem

def run_basic_monitoring_test():
    """Test basic monitoring functionality"""
    print("Testing basic monitoring import...", end=" ")
    try:
        sys.path.append(os.path.join(os.path.dirname(__file__), 'modules'))
        from modules.realtime_monitor import RealTimeMonitoringManager
        print("✓ Monitoring module imported successfully")
        return True
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False

def main():
    """Main verification function"""
    print("Instagram Account Security Assessment Tool - Setup Verification")
    print("=" * 65)
    print(f"Platform: {platform.platform()}")
    print(f"Python executable: {sys.executable}")
    print()
    
    tests = [
        ("Python Version Check", check_python_version),
        ("Pip Availability Check", check_pip),
        ("Required Packages Check", check_required_packages),
        ("Virtual Environment Check", check_virtual_environment),
        ("Directory Structure Check", check_directories),
        ("Instagram Connectivity Test", test_instagram_fetch),
        ("Monitoring Module Test", run_basic_monitoring_test),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"{test_name}:")
        result = test_func()
        results.append((test_name, result))
        print()
    
    # Summary
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    print("Setup Verification Summary:")
    print("-" * 30)
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{status:4} - {test_name}")
    
    print()
    print(f"Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print("✓ Setup is ready! You can run the tool with: python main.py")
    else:
        print("✗ Some tests failed. Please address the issues above before running the tool.")
        print("  Most importantly, ensure Python 3.7+, pip, and required packages are installed.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)