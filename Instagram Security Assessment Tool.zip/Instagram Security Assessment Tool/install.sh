#!/bin/bash
# Installation script for Instagram Account Security Assessment Tool
# Compatible with Linux, macOS, and Termux

echo "Instagram Account Security Assessment Tool - Installation"
echo "======================================================="

echo "Checking system requirements..."

# Check if Python is installed
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo "Error: Python is not installed or not in PATH."
    echo "Please install Python 3.7+ before continuing."
    echo "On Linux: sudo apt install python3 python3-pip (Ubuntu/Debian)"
    echo "On macOS: Install from https://python.org or 'brew install python'"
    echo "On Termux: pkg install python"
    exit 1
fi

echo "Using Python: $($PYTHON_CMD --version)"
echo

# Check if pip is available
if ! $PYTHON_CMD -m pip --version &> /dev/null; then
    echo "Error: pip is not available."
    echo "Please ensure Python was installed with pip."
    exit 1
fi

echo "Python and pip are available."
echo

# Check if venv module is available
if ! $PYTHON_CMD -c "import venv" &> /dev/null; then
    echo "Error: venv module is not available."
    echo "On Linux, you may need to install python3-venv: sudo apt install python3-venv"
    exit 1
fi

echo "Creating virtual environment..."
$PYTHON_CMD -m venv venv

if [ $? -ne 0 ]; then
    echo "Error: Failed to create virtual environment."
    exit 1
fi

echo "Virtual environment created successfully."
echo

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "Virtual environment activated."
elif [ -f "venv/Scripts/activate" ]; then
    # This won't work in bash, but we'll show an appropriate message
    echo "Virtual environment exists. On Windows, use: venv\\Scripts\\activate"
    source venv/bin/activate 2>/dev/null || echo "Warning: Could not activate virtual environment. On Windows, run in Command Prompt or PowerShell."
else
    echo "Error: Virtual environment activation script not found."
    exit 1
fi

echo

# Upgrade pip in virtual environment
echo "Upgrading pip in virtual environment..."
pip install --upgrade pip

echo

# Check if requirements.txt exists
if [ ! -f "requirements.txt" ]; then
    echo "Error: requirements.txt not found in current directory."
    echo "Please make sure you are running this script from the tool's root directory."
    deactivate 2>/dev/null
    exit 1
fi

echo "Installing required packages from requirements.txt..."
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo
    echo "Installation completed successfully!"
    echo
    echo "To run the tool:"
    echo "  On Linux/macOS/Termux:"
    echo "    source venv/bin/activate"
    echo "    python main.py [username]"
    echo "    deactivate"
    echo
    echo "  On Windows:"
    echo "    venv\\Scripts\\activate"
    echo "    python main.py [username]"
    echo "    deactivate"
    echo
    echo "Or use the run scripts:"
    echo "  Linux/macOS/Termux: ./run.sh [username]"
    echo "  Windows: run.bat [username]"
    echo
else
    echo
    echo "Installation failed."
    echo "Please check the error messages above and try again."
    deactivate 2>/dev/null
    exit 1
fi

# Deactivate virtual environment
if command -v deactivate &> /dev/null; then
    deactivate
    echo "Virtual environment deactivated."
fi

echo "Installation process completed."
exit 0