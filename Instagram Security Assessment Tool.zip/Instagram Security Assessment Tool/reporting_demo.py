#!/usr/bin/env python3
"""
Reporting demo for Instagram Account Security Assessment Tool
"""

import json
import os
from datetime import datetime, timedelta
from modules.realtime_monitor import RealTimeMonitoringManager
from config import Config

def create_sample_data():
    """
    Create sample monitoring data to demonstrate reporting functionality
    """
    # Create sample change logs
    sample_logs = [
        {
            'timestamp': (datetime.now() - timedelta(minutes=30)).isoformat(),
            'username': 'demo_user',
            'changes': [
                {
                    'type': 'biography_change',
                    'field': 'biography',
                    'old_value': 'Old bio description',
                    'new_value': 'New bio description with updated information',
                    'timestamp': (datetime.now() - timedelta(minutes=30)).isoformat()
                }
            ]
        },
        {
            'timestamp': (datetime.now() - timedelta(minutes=15)).isoformat(),
            'username': 'demo_user',
            'changes': [
                {
                    'type': 'external_url_change',
                    'field': 'external_url',
                    'old_value': 'https://old-example.com',
                    'new_value': 'https://new-example.com',
                    'timestamp': (datetime.now() - timedelta(minutes=15)).isoformat()
                }
            ]
        },
        {
            'timestamp': (datetime.now() - timedelta(minutes=5)).isoformat(),
            'username': 'demo_user',
            'changes': [
                {
                    'type': 'name_change',
                    'field': 'full_name',
                    'old_value': 'Old Name',
                    'new_value': 'New Updated Name',
                    'timestamp': (datetime.now() - timedelta(minutes=5)).isoformat()
                }
            ]
        }
    ]
    
    # Write sample data to the changes log file
    log_file = f"{Config.DEFAULT_REPORTS_DIR}/demo_user_changes_log.json"
    with open(log_file, 'w') as f:
        json.dump(sample_logs, f, indent=2)
    
    print(f"Sample monitoring data created at: {log_file}")
    return log_file

def main():
    """
    Main function to demonstrate reporting functionality
    """
    print("Instagram Account Security Assessment Tool - Reporting Demo")
    print("=" * 65)
    print()
    
    # Create sample data for demonstration
    print("Creating sample monitoring data...")
    sample_file = create_sample_data()
    print()
    
    # Create monitoring manager
    monitor_manager = RealTimeMonitoringManager()
    
    print("Generating reports from sample data...")
    print()
    
    # Generate changes report
    try:
        report = monitor_manager.generate_changes_report("demo_user")
        
        print("Changes Summary:")
        print("-" * 30)
        for summary in report['changes_summary']:
            print(f"Account: {summary['username']}")
            print(f"Total Changes: {summary['total_changes']}")
            print(f"Change Types: {summary['change_types']}")
            print(f"First Change: {summary['first_change']}")
            print(f"Latest Change: {summary['latest_change']}")
            print()
        
        print("Detailed Changes:")
        print("-" * 30)
        for log_entry in report['detailed_changes']:
            print(f"Time: {log_entry['timestamp']} | Account: {log_entry['username']}")
            for change in log_entry['changes']:
                print(f"  - {change['type']}: {change['field']} changed from '{change['old_value']}' to '{change['new_value']}'")
        print()
        
        # Export report in different formats
        print("Exporting reports...")
        
        # Export JSON report
        json_report_path = monitor_manager.export_changes_report("demo_user", "json")
        print(f"JSON report exported to: {json_report_path}")
        
        # Export TXT report
        txt_report_path = monitor_manager.export_changes_report("demo_user", "txt")
        print(f"TXT report exported to: {txt_report_path}")
        
        print()
        print("Reports generated successfully!")
        print()
        print("The reports contain detailed information about profile changes")
        print("including timestamps, change types, and before/after values.")
        print()
        print("In a real implementation, these reports would contain actual")
        print("changes detected by the real-time monitoring system.")
        
    except Exception as e:
        print(f"Error generating reports: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()