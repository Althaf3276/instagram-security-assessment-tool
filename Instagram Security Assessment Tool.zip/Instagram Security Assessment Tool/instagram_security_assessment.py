#!/usr/bin/env python3
"""
Instagram Account Security Assessment Tool
A professional, ethical tool for performing non-intrusive OSINT-based reconnaissance
on publicly available Instagram profile data, analyzing security posture, and providing
hardening recommendations.
"""

import json
import os
import re
import sys
import time
import requests
from datetime import datetime
from typing import Dict, List, Optional, Any
import argparse
import logging
from urllib.parse import urlparse
import hashlib
import string
from config import Config

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class InstagramSecurityAssessment:
    """
    Main class for Instagram Account Security Assessment
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': Config.USER_AGENT
        })
        self.results = {}
        self.security_score = 100
        self.risk_factors = []
        
    def validate_username(self, username: str) -> bool:
        """
        Validate Instagram username format
        """
        if not username:
            return False
        
        # Instagram username rules: 3-30 characters, letters, numbers, underscores, periods
        pattern = r'^[A-Za-z0-9._]{3,30}$'
        return bool(re.match(pattern, username))
    
    def check_account_existence(self, username: str) -> bool:
        """
        Check if Instagram account exists using public API
        This is a read-only check that doesn't interact with the account
        """
        try:
            # Using Instagram's public profile endpoint (this is a simulated approach)
            # In a real implementation, we'd use Instagram's public API or web scraping
            # that respects robots.txt and rate limits
            url = f"https://www.instagram.com/{username}/?__a=1&__d=dis"
            response = self.session.get(url, timeout=Config.DEFAULT_TIMEOUT)
            
            # Note: Instagram has changed their API, so this is illustrative
            # In a real tool, we'd use proper public methods
            return response.status_code == 200
        except requests.exceptions.RequestException as e:
            logger.warning(f"Could not verify account existence: {e}")
            return True  # Assume exists for demo purposes
        except Exception as e:
            logger.error(f"Unexpected error while checking account existence: {e}")
            return True  # Assume exists for demo purposes
    
    def analyze_profile_data(self, username: str) -> Dict[str, Any]:
        """
        Analyze publicly available profile data
        """
        logger.info(f"Analyzing profile data for: {username}")
        
        profile_data = {
            'username': username,
            'profile_picture': None,
            'full_name': None,
            'biography': None,
            'external_url': None,
            'followers_count': 0,
            'following_count': 0,
            'posts_count': 0,
            'is_private': False,
            'is_verified': False,
            'business_account': False,
            'connected_fb_page': None,
            'has_channel': False,
            'is_joined_recently': None,
            'business_category': None,
            'contact_phone_number': None,
            'public_email': None,
            'public_phone': None,
        }
        
        # In a real implementation, this would fetch public data
        # For demo purposes, we'll return sample data
        # Add more detailed analysis
        self._apply_risk_factors_from_profile(profile_data)
        
        return profile_data
    
    def _apply_risk_factors_from_profile(self, profile_data: Dict[str, Any]):
        """
        Apply risk factors based on profile data
        """
        # Check for risky information in biography
        if profile_data.get('biography'):
            bio = profile_data['biography'].lower()
            
            # Personal information risks
            personal_indicators = ['phone', 'email', 'home', 'address', 'location', 'birth', 'bday', 'birthday', 'age', 'school', 'university', 'work', 'job', 'company', 'husband', 'wife', 'child', 'son', 'daughter', 'mother', 'father']
            for indicator in personal_indicators:
                if indicator in bio:
                    self.risk_factors.append(f"Biography contains potential personal information: {indicator}")
                    self.security_score -= 5
        
        # Check for sensitive contact information
        contact_fields = ['contact_phone_number', 'public_email', 'public_phone']
        for field in contact_fields:
            if profile_data.get(field):
                self.risk_factors.append(f"Public contact information exposed: {field}")
                self.security_score -= 10
        
        # Check for business account risks
        if profile_data.get('business_account'):
            self.risk_factors.append("Business account - may have different security considerations")
            self.security_score -= 2
        
        # Check if account is new (potential risk)
        if profile_data.get('is_joined_recently'):
            self.risk_factors.append("Account joined recently - potential for less established security practices")
            self.security_score -= 3
        
        # Check external URL for risks
        if profile_data.get('external_url'):
            url = profile_data['external_url']
            if self._is_suspicious_url(url):
                self.risk_factors.append(f"Suspicious external URL: {url}")
                self.security_score -= 10
        
        # Check for high follower/following ratios (potential fake account)
        followers = profile_data.get('followers_count', 0)
        following = profile_data.get('following_count', 0)
        if following > 0 and (followers / following) < 0.1:  # Following many more than followers
            self.risk_factors.append("Unusual follower/following ratio - potential fake or spam account")
            self.security_score -= 5
    
    def _is_suspicious_url(self, url: str) -> bool:
        """
        Check if URL is potentially suspicious
        """
        try:
            parsed = urlparse(url)
            suspicious_patterns = [
                'bit.ly', 'tinyurl', 'goo.gl',  # URL shorteners
                'phishing', 'login', 'verify',  # Suspicious keywords
            ]
            
            for pattern in suspicious_patterns:
                if pattern in parsed.netloc.lower() or pattern in parsed.path.lower():
                    return True
            return False
        except:
            return True
    
    def assess_username_reuse(self, username: str) -> Dict[str, Any]:
        """
        Assess username reuse across platforms (OSINT-based)
        """
        logger.info(f"Assessing username reuse for: {username}")
        
        platforms = {}
        for platform_info in Config.OSINT_PLATFORMS:
            platform_name = platform_info['name']
            url_template = platform_info['url_template']
            platforms[platform_name] = {
                'url': url_template.format(username),
                'weight': platform_info['weight']
            }
        
        results = {}
        
        for platform, platform_data in platforms.items():
            url = platform_data['url']
            weight = platform_data['weight']
            try:
                # Simulate checking if username exists on platform
                # In a real implementation, we'd make actual requests with proper rate limiting
                exists = self._check_username_exists(url, platform)
                results[platform] = {
                    'url': url,
                    'weight': weight,
                    'exists': exists,
                    'risk_level': 'medium' if exists else 'none'
                }
                
                if exists:
                    # Apply score penalty based on platform weight
                    penalty = int(2 * weight)  # Weighted penalty
                    self.security_score -= penalty
                    self.risk_factors.append(f"Username reused on {platform}")
                    
            except Exception as e:
                logger.warning(f"Could not check {platform}: {e}")
                results[platform] = {
                    'url': url,
                    'weight': weight,
                    'exists': False,
                    'risk_level': 'unknown'
                }
        
        return results
    
    def _check_username_exists(self, url: str, platform: str) -> bool:
        """
        Check if username exists on a platform
        In a real implementation, this would make actual requests
        """
        try:
            # Add a small delay to be respectful to servers
            time.sleep(Config.DEFAULT_RATE_LIMIT_DELAY)
            
            response = self.session.get(url, timeout=Config.DEFAULT_TIMEOUT)
            
            # Different platforms have different indicators for user existence
            # This is a simplified check - in real implementation we'd have platform-specific logic
            status_indicators = {
                'twitter': lambda r: r.status_code == 200 and 'user' in r.text.lower(),
                'github': lambda r: r.status_code == 200 and 'not found' not in r.text.lower(),
                'reddit': lambda r: r.status_code == 200 and 'user' in r.text.lower(),
                'tiktok': lambda r: r.status_code == 200 and 'user' in r.text.lower(),
                'youtube': lambda r: r.status_code == 200 and ('user' in r.text.lower() or 'channel' in r.text.lower()),
                'pinterest': lambda r: r.status_code == 200 and 'profile' in r.text.lower(),
                'snapchat': lambda r: r.status_code == 200 and 'add' in r.text.lower(),
                'linkedin': lambda r: r.status_code == 200 and 'in' in r.text.lower(),
            }
            
            if platform in status_indicators:
                return status_indicators[platform](response)
            else:
                # Default check
                return response.status_code == 200
                
        except requests.exceptions.RequestException as e:
            logger.warning(f"Could not check {platform} ({url}): {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error checking {platform}: {e}")
            return False
    
    def analyze_email_domain_risks(self, username: str) -> Dict[str, Any]:
        """
        Analyze potential email and domain risks associated with the account
        """
        logger.info(f"Analyzing email/domain risks for: {username}")
        
        # Extract potential email patterns from username using configured domains
        potential_emails = [f"{username}@{domain}" for domain in Config.COMMON_EMAIL_DOMAINS]
        
        # Check for common patterns that might indicate business email
        business_patterns = [
            r'[a-z]+\.[a-z]+@',  # first.last@domain
            r'[a-z][0-9]+@',     # name123@domain
            r'[a-z]+_[a-z]+@'    # first_last@domain
        ]
        
        risks = []
        for email in potential_emails:
            if any(re.search(pattern, email) for pattern in business_patterns):
                risks.append(f"Potential business email pattern detected: {email}")
        
        return {
            'potential_emails': potential_emails,
            'business_email_risk': len(risks) > 0,
            'risks': risks
        }
    
    def simulate_password_strength(self, username: str) -> Dict[str, Any]:
        """
        Simulate password strength assessment (offline simulation)
        """
        logger.info(f"Simulating password strength assessment for: {username}")
        
        # This is an offline simulation - no actual password checking
        # We analyze patterns that might indicate weak password practices
        common_passwords = []
        for pattern in Config.COMMON_PASSWORD_PATTERNS:
            if '{}' in pattern:
                common_passwords.append(pattern.format(username))
            else:
                common_passwords.append(pattern)
        
        weak_patterns = [
            f"{username}123",
            f"{username}1",
            username,
            username[::-1],  # reversed username
        ]
        
        # Simulate password strength based on username patterns
        assessment = {
            'username_based_patterns': weak_patterns,
            'common_passwords_to_avoid': common_passwords,
            'recommendation': 'Use unique, complex passwords not based on username',
            'password_tips': [
                'Use at least 12 characters',
                'Include uppercase, lowercase, numbers, and special characters',
                'Avoid using personal information',
                'Use different passwords for different accounts',
                'Consider using a password manager'
            ]
        }
        
        # Reduce score if username is too simple
        if len(username) < 6:
            self.security_score -= 10
            self.risk_factors.append("Short username may indicate weak password habits")
        
        return assessment
    
    def evaluate_2fa_strength(self) -> Dict[str, Any]:
        """
        Evaluate 2FA/MFA strength (informational only)
        """
        logger.info("Evaluating 2FA/MFA strength")
        
        mfa_assessment = {
            'recommended_methods': [
                {'method': 'Authenticator App', 'strength': 'high', 'description': 'TOTP-based apps like Google Authenticator or Authy'},
                {'method': 'Hardware Security Key', 'strength': 'highest', 'description': 'Physical keys like YubiKey'},
                {'method': 'SMS', 'strength': 'medium', 'description': 'SMS codes (vulnerable to SIM swapping)'}
            ],
            'mfa_best_practices': [
                'Enable 2FA on all accounts',
                'Use authenticator apps over SMS when possible',
                'Keep backup codes in a secure location',
                'Register multiple authentication methods'
            ],
            'current_status': 'Informational - actual 2FA status unknown without account access'
        }
        
        # Add informational risk if not using strong 2FA
        self.risk_factors.append("2FA/MFA is highly recommended for all accounts")
        
        return mfa_assessment
    
    def assess_recovery_flow_risks(self) -> Dict[str, Any]:
        """
        Assess account recovery flow risks (informational)
        """
        logger.info("Assessing account recovery flow risks")
        
        recovery_assessment = {
            'recovery_options': [
                'Email recovery',
                'Phone number recovery',
                'Trusted contacts',
                'Recovery codes'
            ],
            'recovery_risks': [
                'Recovery email compromised',
                'Phone number SIM swapping',
                'Recovery questions too easy to guess'
            ],
            'recommendations': [
                'Use multiple recovery methods',
                'Keep recovery information current',
                'Use unique, hard-to-guess recovery questions',
                'Secure your email and phone number accounts'
            ]
        }
        
        return recovery_assessment
    
    def simulate_phishing_susceptibility(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Simulate phishing susceptibility based on profile information
        """
        logger.info("Simulating phishing susceptibility")
        
        # Analyze profile for information that could be used in phishing
        sus_factors = []
        score_reduction = 0
        
        # Check biography for personal information
        bio = profile_data.get('biography', '').lower()
        if any(word in bio for word in ['work', 'job', 'company', 'position', 'employee', 'corporate', 'office']):
            sus_factors.append("Profile mentions work/company - potential for spear-phishing")
            score_reduction += 10
            
        # Check for personal details
        personal_details = ['birthday', 'birth', 'age', 'location', 'city', 'country', 'school', 'university', 'family', 'husband', 'wife', 'child', 'son', 'daughter', 'mother', 'father']
        for detail in personal_details:
            if detail in bio:
                sus_factors.append(f"Personal detail '{detail}' in profile - potential for social engineering")
                score_reduction += 5
        
        # Check for contact information
        contact_info = ['email', 'phone', 'mobile', 'tel', 'contact']
        for info in contact_info:
            if info in bio:
                sus_factors.append(f"Contact information '{info}' in profile - potential for targeted phishing")
                score_reduction += 7
        
        # Check for interests that might indicate susceptibility
        interest_indicators = ['crypto', 'money', 'finance', 'investment', 'prize', 'winner', 'free']
        for indicator in interest_indicators:
            if indicator in bio:
                sus_factors.append(f"Interest in '{indicator}' - potential for themed phishing")
                score_reduction += 4
        
        # Check for external links
        if profile_data.get('external_url'):
            sus_factors.append("External link present - potential for targeted attacks")
            score_reduction += 5
        
        # Check for business account (more likely target)
        if profile_data.get('business_account'):
            sus_factors.append("Business account - higher value phishing target")
            score_reduction += 8
        
        # Check for public contact information
        if profile_data.get('public_email') or profile_data.get('public_phone'):
            sus_factors.append("Public contact information - direct targeting possible")
            score_reduction += 6
        
        self.security_score -= score_reduction
        if score_reduction > 0:
            self.risk_factors.extend(sus_factors)
        
        # Determine susceptibility level
        if score_reduction >= 25:
            susceptibility_level = 'very_high'
        elif score_reduction >= 15:
            susceptibility_level = 'high'
        elif score_reduction >= 8:
            susceptibility_level = 'medium'
        else:
            susceptibility_level = 'low'
        
        return {
            'susceptibility_level': susceptibility_level,
            'risk_factors': sus_factors,
            'score_reduction': score_reduction,
            'mitigation_tips': [
                'Limit personal information in public profiles',
                'Be cautious of unsolicited messages',
                'Verify identity through multiple channels',
                'Educate about common phishing techniques',
                'Be especially wary of messages referencing public information',
                'Use separate contact methods for verification',
                'Regular security awareness training'
            ]
        }
    
    def assess_credential_stuffing_risk(self, username: str) -> Dict[str, Any]:
        """
        Assess credential stuffing risk (informational)
        """
        logger.info("Assessing credential stuffing risk")
        
        # Check if username is common or predictable
        common_usernames = [
            'admin', 'user', 'test', 'demo', 'support',
            'hello', 'welcome', 'info', 'contact'
        ]
        
        risk_level = 'low'
        if username.lower() in common_usernames:
            risk_level = 'high'
            self.security_score -= 15
            self.risk_factors.append("Common username pattern increases credential stuffing risk")
        elif len(username) < 6:
            risk_level = 'medium'
            self.security_score -= 5
            self.risk_factors.append("Short username may be easier to target")
        
        return {
            'risk_level': risk_level,
            'prevention_tips': [
                'Use unique usernames when possible',
                'Enable account lockout protection',
                'Monitor for unusual login attempts',
                'Use strong, unique passwords',
                'Regularly review account security settings',
                'Enable two-factor authentication',
                'Be cautious of third-party app permissions'
            ]
        }
    
    def generate_security_score(self) -> Dict[str, Any]:
        """
        Generate overall security score and breakdown
        """
        logger.info("Generating security score")
        
        # Ensure score is within bounds
        final_score = max(0, min(100, self.security_score))
        
        # Determine security level
        if final_score >= 90:
            level = 'Excellent'
            color = 'green'
            description = 'Account has excellent security posture with minimal risks'
        elif final_score >= 75:
            level = 'Good'
            color = 'lightgreen'
            description = 'Account has good security posture with few minor risks'
        elif final_score >= 60:
            level = 'Fair'
            color = 'yellow'
            description = 'Account has moderate security risks that should be addressed'
        elif final_score >= 40:
            level = 'Poor'
            color = 'orange'
            description = 'Account has significant security risks requiring immediate attention'
        else:
            level = 'Critical'
            color = 'red'
            description = 'Account has critical security risks requiring urgent remediation'
        
        risk_summary = self._categorize_risks()
        
        return {
            'score': final_score,
            'level': level,
            'color': color,
            'description': description,
            'total_possible_points': 100,
            'risk_factors_count': len(self.risk_factors),
            'risk_summary': risk_summary,
            'risk_breakdown': {
                'profile_privacy': len(risk_summary['profile_privacy']),
                'authentication': len(risk_summary['authentication']),
                'social_engineering': len(risk_summary['social_engineering']),
                'account_recovery': len(risk_summary['account_recovery']),
                'data_exposure': len(risk_summary['data_exposure'])
            },
            'recommendation_priority': self._get_recommendation_priority(final_score),
            'security_insights': self._generate_security_insights()
        }
    
    def _generate_security_insights(self) -> Dict[str, Any]:
        """
        Generate additional security insights based on the assessment
        """
        insights = {
            'overall_security_posture': 'high_risk' if self.security_score < 50 else 'medium_risk' if self.security_score < 70 else 'low_risk',
            'primary_risk_factors': [],
            'security_strengths': [],
            'immediate_actions_needed': [],
            'long_term_improvements': []
        }
        
        # Identify primary risk factors
        if any('biography' in risk.lower() for risk in self.risk_factors):
            insights['primary_risk_factors'].append('Public profile information exposure')
        if any('2fa' in risk.lower() or 'mfa' in risk.lower() for risk in self.risk_factors):
            insights['primary_risk_factors'].append('Lack of multi-factor authentication')
        if any('reuse' in risk.lower() for risk in self.risk_factors):
            insights['primary_risk_factors'].append('Username reuse across platforms')
        
        # Identify security strengths (absence of certain risks could be strengths)
        if not any('phishing' in risk.lower() for risk in self.risk_factors):
            insights['security_strengths'].append('Low susceptibility to phishing')
        
        # Suggest immediate actions
        if self.security_score < 70:
            insights['immediate_actions_needed'].extend([
                'Enable multi-factor authentication',
                'Review and minimize public profile information',
                'Change passwords to strong, unique ones'
            ])
        
        # Suggest long-term improvements
        insights['long_term_improvements'].extend([
            'Regular security assessments',
            'Ongoing security awareness training',
            'Monitoring for account compromises',
            'Regular review of connected applications'
        ])
        
        return insights
    
    def _get_recommendation_priority(self, score: int) -> str:
        """
        Get recommendation priority based on security score
        """
        if score >= 90:
            return 'maintenance'  # Focus on maintaining good security
        elif score >= 75:
            return 'improvement'  # Address minor issues
        elif score >= 60:
            return 'action_needed'  # Address moderate risks
        elif score >= 40:
            return 'urgent_attention'  # Address significant risks
        else:
            return 'critical_attention'  # Address critical risks immediately
    
    def _categorize_risks(self) -> Dict[str, List[str]]:
        """
        Categorize risks into different security areas
        """
        categories = {
            'profile_privacy': [],
            'authentication': [],
            'social_engineering': [],
            'account_recovery': [],
            'data_exposure': []
        }
        
        for risk in self.risk_factors:
            if any(keyword in risk.lower() for keyword in ['biography', 'personal', 'information', 'location']):
                categories['profile_privacy'].append(risk)
            elif any(keyword in risk.lower() for keyword in ['password', '2fa', 'mfa', 'authentication']):
                categories['authentication'].append(risk)
            elif any(keyword in risk.lower() for keyword in ['phishing', 'spear', 'social', 'engineering']):
                categories['social_engineering'].append(risk)
            elif any(keyword in risk.lower() for keyword in ['recovery', 'email', 'phone']):
                categories['account_recovery'].append(risk)
            else:
                categories['data_exposure'].append(risk)
        
        return categories
    
    def generate_recommendations(self) -> List[Dict[str, str]]:
        """
        Generate step-by-step security hardening recommendations
        """
        logger.info("Generating security recommendations")
        
        recommendations = []
        
        # Profile privacy recommendations
        recommendations.append({
            'category': 'Profile Privacy',
            'priority': 'high',
            'recommendation': 'Review and minimize personal information in profile',
            'steps': [
                'Remove specific location details from bio',
                'Avoid sharing phone numbers or addresses',
                'Be cautious about workplace information'
            ]
        })
        
        # Authentication recommendations
        recommendations.append({
            'category': 'Authentication',
            'priority': 'critical',
            'recommendation': 'Enable strong two-factor authentication',
            'steps': [
                'Set up authenticator app instead of SMS',
                'Store backup codes securely',
                'Use hardware security keys if available'
            ]
        })
        
        # Password recommendations
        recommendations.append({
            'category': 'Password Security',
            'priority': 'high',
            'recommendation': 'Improve password security practices',
            'steps': [
                'Use unique, complex passwords for each account',
                'Implement a password manager',
                'Avoid using personal information in passwords'
            ]
        })
        
        # Account monitoring recommendations
        recommendations.append({
            'category': 'Account Monitoring',
            'priority': 'medium',
            'recommendation': 'Enable account activity notifications',
            'steps': [
                'Turn on login alerts',
                'Regularly review connected applications',
                'Check login history periodically'
            ]
        })
        
        # OSINT exposure recommendations
        recommendations.append({
            'category': 'OSINT Protection',
            'priority': 'medium',
            'recommendation': 'Minimize online footprint across platforms',
            'steps': [
                'Audit accounts on other platforms with same username',
                'Use different usernames for different platforms when possible',
                'Be consistent with privacy settings across platforms'
            ]
        })
        
        return recommendations
    
    def generate_report(self, username: str, profile_data: Dict[str, Any], 
                       reuse_results: Dict[str, Any], 
                       email_risks: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate comprehensive assessment report
        """
        logger.info("Generating comprehensive report")
        
        report = {
            'assessment_timestamp': datetime.now().isoformat(),
            'target_username': username,
            'assessment_type': 'Instagram Account Security Assessment',
            'scope': 'Public profile analysis, OSINT, simulated security evaluation',
            'disclaimer': 'This assessment uses only publicly available information and simulated checks. No actual attacks are performed.',
            
            'profile_analysis': profile_data,
            'username_reuse_analysis': reuse_results,
            'email_domain_analysis': email_risks,
            
            'password_simulation': self.simulate_password_strength(username),
            'mfa_assessment': self.evaluate_2fa_strength(),
            'recovery_assessment': self.assess_recovery_flow_risks(),
            'phishing_simulation': self.simulate_phishing_susceptibility(profile_data),
            'credential_stuffing_assessment': self.assess_credential_stuffing_risk(username),
            
            'security_score': self.generate_security_score(),
            'recommendations': self.generate_recommendations(),
            'risk_factors': self.risk_factors
        }
        
        return report
    
    def save_report(self, report: Dict[str, Any], format_type: str = 'json') -> str:
        """
        Save assessment report in specified format
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"instagram_security_assessment_{report['target_username']}_{timestamp}"
        
        if format_type.lower() == 'json':
            filepath = f"{Config.DEFAULT_REPORTS_DIR}/{filename}.json"
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
        elif format_type.lower() == 'txt':
            filepath = f"{Config.DEFAULT_REPORTS_DIR}/{filename}.txt"
            with open(filepath, 'w', encoding='utf-8') as f:
                self._write_text_report(f, report)
        else:
            raise ValueError(f"Unsupported format: {format_type}")
        
        logger.info(f"Report saved to: {filepath}")
        return filepath
    
    def _write_text_report(self, file_handle, report: Dict[str, Any]):
        """
        Write a formatted text report
        """
        file_handle.write("Instagram Account Security Assessment Report\n")
        file_handle.write("=" * 50 + "\n\n")
        
        file_handle.write(f"Assessment Date: {report['assessment_timestamp']}\n")
        file_handle.write(f"Target Username: {report['target_username']}\n")
        file_handle.write(f"Assessment Type: {report['assessment_type']}\n\n")
        
        file_handle.write("DISCLAIMER: This assessment uses only publicly available information and simulated checks. No actual attacks are performed.\n\n")
        
        # Security Score
        score_info = report['security_score']
        file_handle.write(f"Security Score: {score_info['score']}/100 ({score_info['level']})\n\n")
        
        # Risk Factors
        file_handle.write("Risk Factors:\n")
        for risk in report['risk_factors']:
            file_handle.write(f"  - {risk}\n")
        file_handle.write("\n")
        
        # Recommendations
        file_handle.write("Security Recommendations:\n")
        for rec in report['recommendations']:
            file_handle.write(f"\n{rec['category']} - Priority: {rec['priority']}\n")
            file_handle.write(f"  Recommendation: {rec['recommendation']}\n")
            file_handle.write("  Steps:\n")
            for step in rec['steps']:
                file_handle.write(f"    - {step}\n")
        file_handle.write("\n")
        
        # Username reuse
        file_handle.write("Username Reuse Analysis:\n")
        reuse_data = report['username_reuse_analysis']
        for platform, data in reuse_data.items():
            if data['exists']:
                file_handle.write(f"  - {platform}: {data['url']} (Exists)\n")
        file_handle.write("\n")

def main():
    """
    Main function to run the Instagram Security Assessment Tool
    """
    parser = argparse.ArgumentParser(
        description="Instagram Account Security Assessment Tool - Ethical OSINT-based security analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This tool performs non-intrusive security assessments using publicly available information.
It does not perform actual attacks or access private account data without authorization.
        
For educational, bug bounty preparation, and defensive security testing purposes only.
Respect privacy, obtain proper consent, and comply with applicable laws.
        """
    )
    
    parser.add_argument("username", help="Instagram username to assess")
    parser.add_argument("--format", choices=['json', 'txt'], default='json', 
                       help="Output format for the report (default: json)")
    parser.add_argument("--output", help="Custom output filename (without extension)")
    
    args = parser.parse_args()
    
    # Validate username
    assessment_tool = InstagramSecurityAssessment()
    
    if not assessment_tool.validate_username(args.username):
        print(f"Error: Invalid Instagram username format: {args.username}")
        print("Instagram usernames must be 3-30 characters and contain only letters, numbers, underscores, and periods.")
        sys.exit(1)
    
    print(f"Starting Instagram Account Security Assessment for: {args.username}")
    print("This tool performs ethical, non-intrusive analysis using only publicly available data.\n")
    
    try:
        # Perform the assessment
        profile_data = assessment_tool.analyze_profile_data(args.username)
        reuse_results = assessment_tool.assess_username_reuse(args.username)
        email_risks = assessment_tool.analyze_email_domain_risks(args.username)
        
        # Generate comprehensive report
        report = assessment_tool.generate_report(
            args.username, 
            profile_data, 
            reuse_results, 
            email_risks
        )
        
        # Save the report
        filepath = assessment_tool.save_report(report, args.format)
        
        # Display summary
        score = report['security_score']['score']
        level = report['security_score']['level']
        risk_count = report['security_score']['risk_factors_count']
        
        print(f"\nAssessment Complete!")
        print(f"Security Score: {score}/100 ({level})")
        print(f"Identified Risk Factors: {risk_count}")
        print(f"Report saved to: {filepath}")
        
        # Show top recommendations
        print(f"\nTop Security Recommendations:")
        for i, rec in enumerate(report['recommendations'][:3], 1):
            print(f"{i}. {rec['recommendation']}")
        
        print(f"\nFor full details, see the report: {filepath}")
        
    except KeyboardInterrupt:
        print("\nAssessment interrupted by user.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"An error occurred during assessment: {e}")
        print(f"Error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()