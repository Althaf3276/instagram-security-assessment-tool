# Instagram Account Security Assessment Tool - Real-time Monitoring Guide

## Overview

The real-time monitoring feature continuously checks Instagram accounts for changes and provides immediate alerts when changes are detected. This includes monitoring for username changes, profile updates, and other account modifications.

## How Real-time Monitoring Works

### 1. Profile Data Fetching
- The system fetches public Instagram profile data using web scraping techniques
- It parses the embedded JSON data in Instagram's HTML response
- Only publicly available information is accessed

### 2. Change Detection
- The system compares current profile data with previously stored data
- When differences are detected, change alerts are generated
- Supported change types include:
  - Username changes
  - Full name changes
  - Biography updates
  - External URL changes
  - Privacy setting changes
  - Post count changes
  - Follower/following count changes
  - Verification status changes

### 3. Alert System
- Changes trigger real-time alerts with severity levels
- High severity: Privacy changes, username changes, verification changes
- Medium severity: Name changes, URL changes, biography changes
- Low severity: Follower/following count changes, post count changes

## Setting Up Real-time Monitoring

### Prerequisites
1. Python 3.7+ installed
2. Required packages installed (`pip install -r requirements.txt`)
3. Virtual environment activated (recommended)

### Installation Steps
```bash
# Clone or download the repository
# Navigate to the tool directory
cd Instagram\ Security\ Assessment\ Tool

# Install dependencies
python install.py

# Or manually install requirements
pip install -r requirements.txt
```

### Running Real-time Monitoring

#### Method 1: Interactive Mode
```bash
python main.py
# Select option 4: Real-time Monitoring Setup
```

#### Method 2: Direct Monitoring Test
```bash
python test_monitoring.py
```

## Monitoring Configuration

### Check Intervals
- Default interval: 300 seconds (5 minutes)
- Minimum interval: 60 seconds (1 minute)
- Maximum interval: 3600 seconds (1 hour)

### Monitored Fields
The system monitors these profile fields for changes:
- `username` - Instagram username
- `full_name` - Display name
- `biography` - Profile bio
- `external_url` - Linked website
- `followers_count` - Number of followers
- `following_count` - Number followed
- `posts_count` - Number of posts
- `is_private` - Privacy setting
- `is_verified` - Verification status

## Real-time Alert System

When changes are detected, the system provides:
1. Console notifications with emojis
2. Detailed change information
3. Timestamp of when the change occurred
4. Severity level classification
5. Log entries in JSON format

Example alert format:
```
🚨 REAL-TIME ALERT: Username Change for @username
   Field: username
   Old Value: oldusername
   New Value: newusername
   Time: 2023-12-07T10:30:45.123456
   Severity: HIGH
```

## Testing the Monitoring System

### Basic Test
```bash
python test_realtime_functionality.py
```

### Full Test
```bash
python test_monitoring.py
# Choose option 1: Basic monitoring functionality test
```

### Real-time Test
```bash
python test_monitoring.py
# Choose option 2: Real-time monitoring test (30s)
```

## Troubleshooting

### Common Issues

#### 1. Cannot Fetch Profile Data
- **Cause**: Network connectivity issues or Instagram rate limiting
- **Solution**: Check internet connection and wait before retrying

#### 2. No Changes Detected
- **Cause**: Profile hasn't actually changed or monitoring interval is too long
- **Solution**: Make sure the Instagram account has actually changed, or decrease monitoring interval

#### 3. Rate Limiting
- **Cause**: Too frequent requests to Instagram
- **Solution**: Increase monitoring interval or implement additional delays

### Verification Steps

1. **Check Python Installation**:
   ```bash
   python --version
   ```

2. **Verify Dependencies**:
   ```bash
   pip list | grep -i requests
   ```

3. **Test Profile Fetching**:
   ```bash
   python -c "from modules.realtime_monitor import RealTimeMonitor; m = RealTimeMonitor(); print(m.get_profile_data('instagram'))"
   ```

## Security and Privacy

### Ethical Guidelines
- Only monitor accounts you own or have explicit permission to monitor
- Respect Instagram's Terms of Service
- Use only publicly available information
- Do not attempt to access private account data without authorization

### Data Handling
- All monitoring data is stored locally
- No data is transmitted to external servers
- Profile snapshots are stored in JSON format
- Change logs are maintained for historical tracking

## Performance Considerations

- Monitor only necessary accounts to avoid rate limiting
- Adjust monitoring intervals based on need vs. rate limits
- Consider using Instagram's official API for production use
- Be respectful of Instagram's servers and other users

## Expected Behavior

When properly configured, the real-time monitoring system will:
1. Fetch Instagram profile data at specified intervals
2. Compare current data with previous snapshots
3. Detect any changes to monitored fields
4. Generate immediate alerts for detected changes
5. Log changes to JSON files for reporting
6. Display alerts with appropriate severity levels

For username changes specifically, the system will immediately detect and alert when an Instagram username is changed, showing both the old and new username values.

## Support

If you encounter issues:
1. Verify Python and dependencies are properly installed
2. Check network connectivity
3. Review the logs in the reports directory
4. Ensure you're only monitoring accounts you have permission to monitor