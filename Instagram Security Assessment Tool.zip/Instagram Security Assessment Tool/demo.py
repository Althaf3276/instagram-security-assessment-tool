#!/usr/bin/env python3
"""
Demo script for Instagram Account Security Assessment Tool
This demonstrates the tool's capabilities with a sample assessment
"""

import os
import sys
import json
from datetime import datetime

# Add the src directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

def run_demo():
    """
    Run a demonstration of the Instagram Security Assessment Tool
    """
    print("Instagram Account Security Assessment Tool - Demo")
    print("=" * 55)
    print()
    print("This demo simulates the assessment process with sample data.")
    print("In a real implementation, this would connect to public APIs and")
    print("perform OSINT analysis on actual Instagram accounts.")
    print()

    # Simulated assessment results
    demo_results = {
        'assessment_timestamp': datetime.now().isoformat(),
        'target_username': 'demo_user',
        'assessment_type': 'Instagram Account Security Assessment',
        'scope': 'Public profile analysis, OSINT, simulated security evaluation',
        'disclaimer': 'This assessment uses only publicly available information and simulated checks. No actual attacks are performed.',
        
        'profile_analysis': {
            'username': 'demo_user',
            'profile_picture': 'available',
            'full_name': 'Demo User',
            'biography': 'Software developer | Security enthusiast | Traveler',
            'external_url': 'https://example.com/demo',
            'followers_count': 1250,
            'following_count': 890,
            'posts_count': 245,
            'is_private': False,
            'is_verified': False
        },
        
        'username_reuse_analysis': {
            'twitter': {'url': 'https://twitter.com/demo_user', 'exists': True, 'risk_level': 'medium'},
            'github': {'url': 'https://github.com/demo_user', 'exists': True, 'risk_level': 'medium'},
            'reddit': {'url': 'https://reddit.com/user/demo_user', 'exists': False, 'risk_level': 'none'},
            'tiktok': {'url': 'https://tiktok.com/@demo_user', 'exists': True, 'risk_level': 'medium'},
            'youtube': {'url': 'https://youtube.com/user/demo_user', 'exists': False, 'risk_level': 'none'},
            'pinterest': {'url': 'https://pinterest.com/demo_user', 'exists': True, 'risk_level': 'medium'},
            'snapchat': {'url': 'https://snapchat.com/add/demo_user', 'exists': False, 'risk_level': 'none'}
        },
        
        'email_domain_analysis': {
            'potential_emails': [
                'demo_user@gmail.com',
                'demo_user@yahoo.com',
                'demo_user@outlook.com',
                'demo_user@icloud.com'
            ],
            'business_email_risk': False,
            'risks': []
        },
        
        'password_simulation': {
            'username_based_patterns': ['demo_user123', 'demo_user1', 'demo_user'],
            'common_passwords_to_avoid': ['123456', 'password', 'demo_user123'],
            'recommendation': 'Use unique, complex passwords not based on username',
            'password_tips': [
                'Use at least 12 characters',
                'Include uppercase, lowercase, numbers, and special characters',
                'Avoid using personal information',
                'Use different passwords for different accounts',
                'Consider using a password manager'
            ]
        },
        
        'mfa_assessment': {
            'recommended_methods': [
                {'method': 'Authenticator App', 'strength': 'high', 'description': 'TOTP-based apps like Google Authenticator or Authy'},
                {'method': 'Hardware Security Key', 'strength': 'highest', 'description': 'Physical keys like YubiKey'},
                {'method': 'SMS', 'strength': 'medium', 'description': 'SMS codes (vulnerable to SIM swapping)'}
            ],
            'mfa_best_practices': [
                'Enable 2FA on all accounts',
                'Use authenticator apps over SMS when possible',
                'Keep backup codes in a secure location',
                'Register multiple authentication methods'
            ],
            'current_status': 'Informational - actual 2FA status unknown without account access'
        },
        
        'recovery_assessment': {
            'recovery_options': [
                'Email recovery',
                'Phone number recovery',
                'Trusted contacts',
                'Recovery codes'
            ],
            'recovery_risks': [
                'Recovery email compromised',
                'Phone number SIM swapping',
                'Recovery questions too easy to guess'
            ],
            'recommendations': [
                'Use multiple recovery methods',
                'Keep recovery information current',
                'Use unique, hard-to-guess recovery questions',
                'Secure your email and phone number accounts'
            ]
        },
        
        'phishing_simulation': {
            'susceptibility_level': 'medium',
            'risk_factors': [
                "Profile mentions work/company - potential for spear-phishing",
                "Personal detail 'traveler' in profile - potential for social engineering"
            ],
            'mitigation_tips': [
                'Limit personal information in public profiles',
                'Be cautious of unsolicited messages',
                'Verify identity through multiple channels',
                'Educate about common phishing techniques'
            ]
        },
        
        'credential_stuffing_assessment': {
            'risk_level': 'medium',
            'prevention_tips': [
                'Use unique usernames when possible',
                'Enable account lockout protection',
                'Monitor for unusual login attempts',
                'Use strong, unique passwords'
            ]
        },
        
        'security_score': {
            'score': 68,
            'level': 'Fair',
            'color': 'yellow',
            'total_possible_points': 100,
            'risk_factors_count': 5,
            'risk_summary': {
                'profile_privacy': ['Profile mentions work/company - potential for spear-phishing', "Personal detail 'traveler' in profile - potential for social engineering"],
                'authentication': ['2FA/MFA is highly recommended for all accounts'],
                'social_engineering': [],
                'account_recovery': [],
                'data_exposure': ['Username reused on twitter', 'Username reused on github', 'Username reused on tiktok', 'Username reused on pinterest']
            }
        },
        
        'recommendations': [
            {
                'category': 'Profile Privacy',
                'priority': 'high',
                'recommendation': 'Review and minimize personal information in profile',
                'steps': [
                    'Remove specific location details from bio',
                    'Avoid sharing phone numbers or addresses',
                    'Be cautious about workplace information'
                ]
            },
            {
                'category': 'Authentication',
                'priority': 'critical',
                'recommendation': 'Enable strong two-factor authentication',
                'steps': [
                    'Set up authenticator app instead of SMS',
                    'Store backup codes securely',
                    'Use hardware security keys if available'
                ]
            },
            {
                'category': 'Password Security',
                'priority': 'high',
                'recommendation': 'Improve password security practices',
                'steps': [
                    'Use unique, complex passwords for each account',
                    'Implement a password manager',
                    'Avoid using personal information in passwords'
                ]
            },
            {
                'category': 'Account Monitoring',
                'priority': 'medium',
                'recommendation': 'Enable account activity notifications',
                'steps': [
                    'Turn on login alerts',
                    'Regularly review connected applications',
                    'Check login history periodically'
                ]
            },
            {
                'category': 'OSINT Protection',
                'priority': 'medium',
                'recommendation': 'Minimize online footprint across platforms',
                'steps': [
                    'Audit accounts on other platforms with same username',
                    'Use different usernames for different platforms when possible',
                    'Be consistent with privacy settings across platforms'
                ]
            }
        ],
        
        'risk_factors': [
            'Profile mentions work/company - potential for spear-phishing',
            "Personal detail 'traveler' in profile - potential for social engineering",
            '2FA/MFA is highly recommended for all accounts',
            'Username reused on twitter',
            'Username reused on github',
            'Username reused on tiktok',
            'Username reused on pinterest'
        ]
    }
    
    # Display summary
    print(f"Demo Assessment Results:")
    print(f"Target Username: {demo_results['target_username']}")
    print(f"Security Score: {demo_results['security_score']['score']}/100 ({demo_results['security_score']['level']})")
    print(f"Risk Factors Identified: {demo_results['security_score']['risk_factors_count']}")
    print()
    
    # Show risk summary
    print("Risk Summary by Category:")
    for category, risks in demo_results['security_score']['risk_summary'].items():
        if risks:  # Only show categories with risks
            print(f"  {category.replace('_', ' ').title()}: {len(risks)} risk(s)")
            for risk in risks[:2]:  # Show first 2 risks in each category
                print(f"    - {risk}")
            if len(risks) > 2:
                print(f"    ... and {len(risks) - 2} more")
    print()
    
    # Show top recommendations
    print("Top Security Recommendations:")
    for i, rec in enumerate(demo_results['recommendations'][:3], 1):
        print(f"{i}. {rec['recommendation']}")
        print(f"   Priority: {rec['priority'].title()}")
        print(f"   Steps: {', '.join(rec['steps'][:2])}{'...' if len(rec['steps']) > 2 else ''}")
    print()
    
    # Show how to run the actual tool
    print("To run the actual assessment tool:")
    print("  python instagram_security_assessment.py <instagram_username>")
    print()
    print("For example:")
    print("  python instagram_security_assessment.py demo_user")
    print()
    print("The tool will perform a comprehensive security assessment and generate a detailed report.")
    
    # Save demo results as a sample report
    try:
        os.makedirs('reports', exist_ok=True)
        demo_report_path = 'reports/demo_assessment.json'
        with open(demo_report_path, 'w', encoding='utf-8') as f:
            json.dump(demo_results, f, indent=2)
        print(f"\nDemo report saved to: {demo_report_path}")
    except Exception as e:
        print(f"Could not save demo report: {e}")

if __name__ == "__main__":
    run_demo()