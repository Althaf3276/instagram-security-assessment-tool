#!/bin/bash
# Run script for Instagram Account Security Assessment Tool
# Compatible with Linux, macOS, and Termux

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Virtual environment not found. Please run install.sh first."
    exit 1
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
else
    echo "Virtual environment activation script not found."
    exit 1
fi

# Check if Python is available
if ! command -v python &> /dev/null; then
    echo "Python not found in virtual environment."
    exit 1
fi

echo "Instagram Account Security Assessment Tool"
echo "=========================================="
echo

# Run the tool with provided arguments or show help
if [ $# -eq 0 ]; then
    python main.py --help
else
    python main.py "$@"
fi

# Deactivate virtual environment
if command -v deactivate &> /dev/null; then
    deactivate
fi