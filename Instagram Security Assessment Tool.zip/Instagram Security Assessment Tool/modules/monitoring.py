"""
Monitoring module for Instagram Account Security Assessment Tool
Provides user-authorized monitoring and alerting capabilities
"""

import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging
from config import Config

logger = logging.getLogger(__name__)

class AccountMonitor:
    """
    Provides monitoring and alerting for Instagram account security
    """
    
    def __init__(self, username: str):
        self.username = username
        self.monitoring_data_file = f"{Config.DEFAULT_REPORTS_DIR}/{username}_monitoring.json"
        self.alerts_file = f"{Config.DEFAULT_REPORTS_DIR}/{username}_alerts.json"
        self.setup_monitoring_data()
        
    def setup_monitoring_data(self):
        """
        Initialize monitoring data structure
        """
        if not os.path.exists(self.monitoring_data_file):
            initial_data = {
                'username': self.username,
                'created_at': datetime.now().isoformat(),
                'last_check': None,
                'activity_log': [],
                'suspicious_activities': [],
                'connected_apps': [],
                'login_history': [],
                'profile_changes': []
            }
            
            with open(self.monitoring_data_file, 'w') as f:
                json.dump(initial_data, f, indent=2)
                
        if not os.path.exists(self.alerts_file):
            with open(self.alerts_file, 'w') as f:
                json.dump({'alerts': []}, f, indent=2)
    
    def log_activity(self, activity_type: str, details: Dict[str, Any]):
        """
        Log account activity for monitoring
        """
        data = self._load_monitoring_data()
        activity = {
            'timestamp': datetime.now().isoformat(),
            'type': activity_type,
            'details': details
        }
        data['activity_log'].append(activity)
        data['last_check'] = datetime.now().isoformat()
        self._save_monitoring_data(data)
        
        logger.info(f"Logged activity: {activity_type} for {self.username}")
    
    def check_for_suspicious_activity(self) -> List[Dict[str, Any]]:
        """
        Check for potentially suspicious activities
        """
        data = self._load_monitoring_data()
        suspicious_activities = []
        
        # Check for unusual login patterns (simulated)
        recent_logins = [log for log in data['activity_log'] 
                        if log['type'] == 'login' and 
                        self._is_recent(log['timestamp'], hours=24)]
        
        if len(recent_logins) > 5:  # More than 5 logins in 24 hours
            suspicious_activities.append({
                'type': 'unusual_login_frequency',
                'description': f'Unusual number of logins ({len(recent_logins)}) in 24 hours',
                'timestamp': datetime.now().isoformat(),
                'severity': 'medium'
            })
        
        # Check for new app connections
        recent_app_connections = [log for log in data['activity_log'] 
                                if log['type'] == 'app_connection' and 
                                self._is_recent(log['timestamp'], hours=24)]
        
        if recent_app_connections:
            suspicious_activities.append({
                'type': 'new_app_connections',
                'description': f'New app connections detected ({len(recent_app_connections)})',
                'timestamp': datetime.now().isoformat(),
                'severity': 'high'
            })
        
        # NEW: Check for profile changes
        recent_profile_changes = [log for log in data['activity_log']
                                if log['type'] == 'profile_change' and
                                self._is_recent(log['timestamp'], hours=24)]
        
        if recent_profile_changes:
            suspicious_activities.append({
                'type': 'profile_changes',
                'description': f'Profile changes detected ({len(recent_profile_changes)}) in 24 hours',
                'timestamp': datetime.now().isoformat(),
                'severity': 'medium'
            })
        
        # NEW: Check for unusual posting patterns
        recent_posts = [log for log in data['activity_log']
                      if log['type'] == 'post' and
                      self._is_recent(log['timestamp'], hours=1)]  # More than 5 posts in 1 hour
        
        if len(recent_posts) > 5:
            suspicious_activities.append({
                'type': 'unusual_posting_frequency',
                'description': f'Unusual posting frequency ({len(recent_posts)}) in 1 hour',
                'timestamp': datetime.now().isoformat(),
                'severity': 'low'
            })
        
        # NEW: Check for multiple simultaneous logins
        active_sessions = [log for log in data['activity_log']
                         if log['type'] == 'login' and
                         self._is_recent(log['timestamp'], minutes=30)]
        
        if len(active_sessions) > 3:  # More than 3 logins in 30 minutes
            suspicious_activities.append({
                'type': 'multiple_simultaneous_logins',
                'description': f'Multiple simultaneous logins detected ({len(active_sessions)})',
                'timestamp': datetime.now().isoformat(),
                'severity': 'high'
            })
        
        # Add to monitoring data
        data['suspicious_activities'].extend(suspicious_activities)
        self._save_monitoring_data(data)
        
        return suspicious_activities
    
    def real_time_monitor(self, callback_func=None, interval=300):
        """
        Perform real-time monitoring at specified intervals
        
        Args:
            callback_func: Function to call when suspicious activity is detected
            interval: Interval in seconds between checks (default 5 minutes)
        """
        logger.info(f"Starting real-time monitoring for {self.username} with {interval}s intervals")
        
        try:
            while True:
                # Perform a check
                suspicious_activities = self.check_for_suspicious_activity()
                
                if suspicious_activities:
                    for activity in suspicious_activities:
                        self.send_alert(activity['type'], activity['description'], activity['severity'])
                        
                        # Call callback if provided
                        if callback_func:
                            callback_func(activity)
                
                # Sleep for the specified interval
                time.sleep(interval)
                
        except KeyboardInterrupt:
            logger.info("Real-time monitoring stopped by user")
        
    def add_monitoring_event(self, event_type: str, details: Dict[str, Any]):
        """
        Add a monitoring event that can trigger real-time alerts
        """
        self.log_activity(event_type, details)
        
        # Check for suspicious activity immediately
        suspicious_activities = self.check_for_suspicious_activity()
        
        if suspicious_activities:
            for activity in suspicious_activities:
                self.send_alert(activity['type'], activity['description'], activity['severity'])
        
        return suspicious_activities
    
    def _is_recent(self, timestamp_str: str, hours: int = 0, minutes: int = 0) -> bool:
        """
        Check if a timestamp is within the specified number of hours/minutes
        """
        timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        time_diff = timedelta(hours=hours, minutes=minutes)
        return datetime.now() - timestamp < time_diff
    
    def generate_monitoring_report(self) -> Dict[str, Any]:
        """
        Generate a monitoring report
        """
        data = self._load_monitoring_data()
        
        report = {
            'monitoring_period': 'Last 30 days',
            'total_activities': len(data['activity_log']),
            'suspicious_activities_count': len(data['suspicious_activities']),
            'connected_apps_count': len(data['connected_apps']),
            'recent_logins_count': len([log for log in data['activity_log'] if log['type'] == 'login']),
            'profile_changes_count': len(data['profile_changes']),
            'last_check': data['last_check'],
            'recent_suspicious_activities': data['suspicious_activities'][-5:],  # Last 5
            'connected_apps': data['connected_apps'][-10:]  # Last 10
        }
        
        return report
    
    def _load_monitoring_data(self) -> Dict[str, Any]:
        """
        Load monitoring data from file
        """
        try:
            with open(self.monitoring_data_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            # Initialize with default data if file doesn't exist
            self.setup_monitoring_data()
            with open(self.monitoring_data_file, 'r') as f:
                return json.load(f)
    
    def _save_monitoring_data(self, data: Dict[str, Any]):
        """
        Save monitoring data to file
        """
        with open(self.monitoring_data_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def send_alert(self, alert_type: str, message: str, severity: str = 'medium'):
        """
        Send an alert about suspicious activity
        """
        alert = {
            'timestamp': datetime.now().isoformat(),
            'type': alert_type,
            'message': message,
            'severity': severity,
            'acknowledged': False
        }
        
        # Load existing alerts
        try:
            with open(self.alerts_file, 'r') as f:
                alerts_data = json.load(f)
        except FileNotFoundError:
            alerts_data = {'alerts': []}
        
        # Add new alert
        alerts_data['alerts'].append(alert)
        
        # Save updated alerts
        with open(self.alerts_file, 'w') as f:
            json.dump(alerts_data, f, indent=2)
        
        logger.warning(f"Alert generated: [{severity.upper()}] {message}")
    
    def get_unacknowledged_alerts(self) -> List[Dict[str, Any]]:
        """
        Get all unacknowledged alerts
        """
        try:
            with open(self.alerts_file, 'r') as f:
                alerts_data = json.load(f)
            return [alert for alert in alerts_data['alerts'] if not alert.get('acknowledged', False)]
        except FileNotFoundError:
            return []
    
    def acknowledge_alert(self, alert_index: int):
        """
        Acknowledge an alert to mark it as seen
        """
        try:
            with open(self.alerts_file, 'r') as f:
                alerts_data = json.load(f)
            
            if 0 <= alert_index < len(alerts_data['alerts']):
                alerts_data['alerts'][alert_index]['acknowledged'] = True
                
                with open(self.alerts_file, 'w') as f:
                    json.dump(alerts_data, f, indent=2)
                    
                logger.info(f"Alert {alert_index} acknowledged")
        except FileNotFoundError:
            pass

class MonitoringManager:
    """
    Manages multiple account monitors
    """
    
    def __init__(self):
        self.monitors: Dict[str, AccountMonitor] = {}
        self.monitoring_config_file = f"{Config.DEFAULT_REPORTS_DIR}/monitoring_config.json"
        self._load_monitoring_config()
    
    def _load_monitoring_config(self):
        """
        Load monitoring configuration
        """
        try:
            with open(self.monitoring_config_file, 'r') as f:
                config = json.load(f)
                monitored_accounts = config.get('monitored_accounts', [])
                
                # Initialize monitors for all configured accounts
                for username in monitored_accounts:
                    self.add_monitor(username)
        except FileNotFoundError:
            # Create default config if it doesn't exist
            self._save_monitoring_config({'monitored_accounts': []})
    
    def _save_monitoring_config(self, config: Dict[str, Any]):
        """
        Save monitoring configuration
        """
        with open(self.monitoring_config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def add_monitor(self, username: str) -> AccountMonitor:
        """
        Add a new account to monitor
        """
        if username not in self.monitors:
            self.monitors[username] = AccountMonitor(username)
            
            # Update config
            try:
                with open(self.monitoring_config_file, 'r') as f:
                    config = json.load(f)
            except FileNotFoundError:
                config = {'monitored_accounts': []}
            
            if username not in config['monitored_accounts']:
                config['monitored_accounts'].append(username)
                self._save_monitoring_config(config)
        
        return self.monitors[username]
    
    def remove_monitor(self, username: str):
        """
        Remove an account from monitoring
        """
        if username in self.monitors:
            del self.monitors[username]
            
            # Update config
            try:
                with open(self.monitoring_config_file, 'r') as f:
                    config = json.load(f)
                
                if username in config['monitored_accounts']:
                    config['monitored_accounts'].remove(username)
                    self._save_monitoring_config(config)
            except FileNotFoundError:
                pass
    
    def check_all_monitors(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Check all monitored accounts for suspicious activity
        """
        all_suspicious = {}
        
        for username, monitor in self.monitors.items():
            suspicious_activities = monitor.check_for_suspicious_activity()
            if suspicious_activities:
                all_suspicious[username] = suspicious_activities
                
                # Send alerts for each suspicious activity
                for activity in suspicious_activities:
                    monitor.send_alert(
                        activity['type'],
                        activity['description'],
                        activity['severity']
                    )
        
        return all_suspicious
    
    def get_monitoring_report(self, username: str) -> Optional[Dict[str, Any]]:
        """
        Get monitoring report for a specific account
        """
        if username in self.monitors:
            return self.monitors[username].generate_monitoring_report()
        return None

# Example usage and testing
if __name__ == "__main__":
    # Example of how monitoring would work
    print("Instagram Account Security Assessment - Monitoring Module")
    print("=" * 60)
    print()
    print("This module provides authorized monitoring capabilities for Instagram accounts.")
    print("It tracks login activities, app connections, and other security-relevant events.")
    print()
    print("Features:")
    print("- Suspicious activity detection")
    print("- Login pattern analysis") 
    print("- Connected app monitoring")
    print("- Alert generation and management")
    print("- Activity logging")
    print()
    print("Note: This module is designed to work with proper authorization from account owners.")
    print("All monitoring is opt-in and requires explicit consent from account holders.")