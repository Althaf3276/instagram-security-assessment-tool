"""
Real-time monitoring daemon for Instagram Account Security Assessment Tool
Provides continuous monitoring capabilities with real-time alerts
"""

import json
import os
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Callable
import logging
import requests
from config import Config

logger = logging.getLogger(__name__)

class RealTimeMonitor:
    """
    Real-time monitoring daemon that continuously checks Instagram accounts
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': Config.USER_AGENT
        })
        self.monitored_accounts = {}
        self.is_monitoring = False
        self.monitoring_thread = None
        self.check_interval = Config.REALTIME_MONITORING['default_interval']  # Use config setting
        
    def add_account(self, username: str, alerts_callback: Callable = None):
        """
        Add an account to real-time monitoring
        """
        self.monitored_accounts[username] = {
            'username': username,
            'last_check': None,
            'profile_snapshot': None,
            'alerts_callback': alerts_callback,
            'enabled': True
        }
        logger.info(f"Added {username} to real-time monitoring")
        
    def remove_account(self, username: str):
        """
        Remove an account from real-time monitoring
        """
        if username in self.monitored_accounts:
            del self.monitored_accounts[username]
            logger.info(f"Removed {username} from real-time monitoring")
            
    def get_profile_data(self, username: str) -> Dict[str, Any]:
        """
        Get current profile data for comparison by fetching actual Instagram profile data
        """
        try:
            # Create a new session for each request to avoid rate limiting issues
            temp_session = requests.Session()
            temp_session.headers.update({
                'User-Agent': Config.USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Cache-Control': 'max-age=0',
            })
            
            # Fetch the Instagram profile page
            url = f'https://www.instagram.com/{username}/'
            response = temp_session.get(url, timeout=Config.REALTIME_MONITORING['profile_check_timeout'])
            
            if response.status_code != 200:
                logger.warning(f"Failed to fetch profile for {username}, status code: {response.status_code}")
                # Return empty dict to indicate failure
                return {}
            
            # Parse the profile data from the HTML response
            # Instagram embeds profile data in a script tag with type 'application/json'
            import re
            from html import unescape
            
            # Look for the embedded JSON data in the page
            # Updated pattern to match modern Instagram structure
            patterns = [
                r'window\\._sharedData\\s*=\\s*(\\{.*?\\});',
                r'window\\.__additionalDataLoaded\\(\\\\"/[^/]+/\\\\",\\s*(\\{.*?\\})\\);',
                r'"user":(\\{[^}]*\\})',  # For GraphQL user data
                r'id="react-root"[^>]*data-initial[^>]*=\\\\"(.*?)\\\\"'  # For newer structure
            ]
            
            for pattern in patterns:
                matches = re.search(pattern, response.text)
                if matches:
                    json_str = unescape(matches.group(1))
                    import json
                    try:
                        data = json.loads(json_str)
                        
                        # Handle different data structures
                        if 'entry_data' in data and 'ProfilePage' in data['entry_data']:
                            # Standard structure
                            user_data = data['entry_data']['ProfilePage'][0]['graphql']['user']
                        elif 'graphql' in data and 'user' in data['graphql']:
                            # GraphQL structure
                            user_data = data['graphql']['user']
                        elif 'user' in data:
                            # Direct user structure
                            user_data = data['user']
                        else:
                            # Try to find user data in other locations
                            user_data = data
                            # Look for nested user data
                            for key, value in data.items():
                                if isinstance(value, dict) and 'username' in value:
                                    user_data = value
                                    break
                        
                        # Return structured profile data
                        return {
                            'username': user_data.get('username', username),
                            'full_name': user_data.get('full_name', user_data.get('displayName', '')),
                            'biography': user_data.get('biography', ''),
                            'external_url': user_data.get('external_url', user_data.get('external_url', '')),
                            'followers_count': user_data.get('edge_followed_by', {}).get('count', 
                                              user_data.get('followers_count', 0)),
                            'following_count': user_data.get('edge_follow', {}).get('count', 
                                              user_data.get('following_count', 0)),
                            'posts_count': user_data.get('edge_owner_to_timeline_media', {}).get('count', 
                                           user_data.get('media_count', 0)),
                            'is_private': user_data.get('is_private', user_data.get('is_private', False)),
                            'is_verified': user_data.get('is_verified', user_data.get('is_verified', False)),
                            'profile_pic_url': user_data.get('profile_pic_url_hd', 
                                            user_data.get('profile_pic_url', '')),
                            'business_account': user_data.get('is_business_account', 
                                            user_data.get('account_type', '') == 'business'),
                            'connected_fb_page': user_data.get('connected_fb_page', 
                                              user_data.get('connected_fb_page', {})).get('name') if user_data.get('connected_fb_page') else None,
                            'business_category': user_data.get('business_category_name', 
                                             user_data.get('category', None)),
                            'public_email': user_data.get('business_email', user_data.get('public_email', None)),
                            'contact_phone_number': user_data.get('business_phone_number', 
                                                 user_data.get('contact_phone_number', None)),
                            'has_channel': user_data.get('has_channel', user_data.get('has_channel', False)),
                            'is_joined_recently': user_data.get('is_joined_recently', 
                                               user_data.get('is_joined_recently', False)),
                            'show_shopping_tab': user_data.get('show_shopping_tag', 
                                              user_data.get('has_shop', False)),
                            'is_favorite': user_data.get('followed_by_viewer', 
                                           user_data.get('followed_by_viewer', False))
                        }
                    except json.JSONDecodeError:
                        continue  # Try next pattern
            
            # If none of the patterns worked, try to extract basic info from HTML
            # Look for basic profile info in meta tags or other HTML elements
            basic_patterns = [
                r'<meta[^>]*property="og:title"[^>]*content="([^"]*)"',
                r'<meta[^>]*name="description"[^>]*content="([^"]*)"',
                r'<title[^>]*>([^<]*)</title>'
            ]
            
            for pattern in basic_patterns:
                match = re.search(pattern, response.text)
                if match:
                    # Extract basic info if possible
                    title = match.group(1) if match else ""
                    return {
                        'username': username,
                        'full_name': title.split('(')[0].strip() if '(' in title else title.strip(),
                        'biography': '',
                        'external_url': '',
                        'followers_count': 0,
                        'following_count': 0,
                        'posts_count': 0,
                        'is_private': False,
                        'is_verified': False,
                        'profile_pic_url': '',
                        'business_account': False,
                        'connected_fb_page': None,
                        'business_category': None,
                        'public_email': None,
                        'contact_phone_number': None,
                        'has_channel': False,
                        'is_joined_recently': False,
                        'show_shopping_tab': False,
                        'is_favorite': False
                    }
            
            logger.warning(f"Could not extract profile data from {username} page")
            return {}
                    
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error while fetching profile data for {username}: {e}")
            return {}
        except (KeyError, IndexError, ValueError, json.JSONDecodeError) as e:
            logger.error(f"Error parsing profile data for {username}: {e}")
            return {}
        except Exception as e:
            logger.error(f"Unexpected error while fetching profile data for {username}: {e}")
            return {}
    
    def detect_profile_changes(self, username: str) -> List[Dict[str, Any]]:
        """
        Detect changes in profile data since last check
        """
        if username not in self.monitored_accounts:
            return []
            
        current_data = self.get_profile_data(username)
        previous_data = self.monitored_accounts[username].get('profile_snapshot')
        
        changes = []
        
        if previous_data:
            # Compare key profile elements
            if current_data.get('username') != previous_data.get('username'):
                changes.append({
                    'type': 'username_change',
                    'field': 'username',
                    'old_value': previous_data.get('username'),
                    'new_value': current_data.get('username'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('full_name') != previous_data.get('full_name'):
                changes.append({
                    'type': 'name_change',
                    'field': 'full_name',
                    'old_value': previous_data.get('full_name'),
                    'new_value': current_data.get('full_name'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('biography') != previous_data.get('biography'):
                changes.append({
                    'type': 'biography_change',
                    'field': 'biography',
                    'old_value': previous_data.get('biography'),
                    'new_value': current_data.get('biography'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('external_url') != previous_data.get('external_url'):
                changes.append({
                    'type': 'external_url_change',
                    'field': 'external_url',
                    'old_value': previous_data.get('external_url'),
                    'new_value': current_data.get('external_url'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('is_private') != previous_data.get('is_private'):
                changes.append({
                    'type': 'privacy_change',
                    'field': 'is_private',
                    'old_value': previous_data.get('is_private'),
                    'new_value': current_data.get('is_private'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('posts_count') != previous_data.get('posts_count'):
                changes.append({
                    'type': 'post_count_change',
                    'field': 'posts_count',
                    'old_value': previous_data.get('posts_count'),
                    'new_value': current_data.get('posts_count'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('followers_count') != previous_data.get('followers_count'):
                changes.append({
                    'type': 'followers_count_change',
                    'field': 'followers_count',
                    'old_value': previous_data.get('followers_count'),
                    'new_value': current_data.get('followers_count'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('following_count') != previous_data.get('following_count'):
                changes.append({
                    'type': 'following_count_change',
                    'field': 'following_count',
                    'old_value': previous_data.get('following_count'),
                    'new_value': current_data.get('following_count'),
                    'timestamp': datetime.now().isoformat()
                })
                
            if current_data.get('is_verified') != previous_data.get('is_verified'):
                changes.append({
                    'type': 'verification_change',
                    'field': 'is_verified',
                    'old_value': previous_data.get('is_verified'),
                    'new_value': current_data.get('is_verified'),
                    'timestamp': datetime.now().isoformat()
                })
        
        # Update profile snapshot
        self.monitored_accounts[username]['profile_snapshot'] = current_data
        
        # Log changes to a file for reporting
        if changes:
            self._log_changes_to_file(username, changes)
        
        return changes
    
    def _log_changes_to_file(self, username: str, changes: List[Dict[str, Any]]):
        """
        Log detected changes to a file for reporting purposes
        """
        import json
        from datetime import datetime
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'username': username,
            'changes': changes
        }
    
        log_file = f"{Config.DEFAULT_REPORTS_DIR}/{username}_changes_log.json"
    
        # Load existing logs or create new one
        try:
            with open(log_file, 'r') as f:
                logs = json.load(f)
        except FileNotFoundError:
            logs = []
    
        # Add new entry
        logs.append(log_entry)
    
        # Keep only last 100 entries to prevent file from growing too large
        logs = logs[-100:]
    
        # Save back to file
        with open(log_file, 'w') as f:
            json.dump(logs, f, indent=2)
        
    def add_authorized_account(self, username: str, password: str = None, session_data: Dict[str, Any] = None):
        """
        Add an account that requires authentication for deeper monitoring
            
        Note: This is for legitimate security monitoring where the user
        has explicit permission and credentials for the account.
            
        Args:
            username: Instagram username
            password: Password for the account (should be handled securely)
            session_data: Session data for authenticated access
        """
        if username not in self.monitored_accounts:
            self.monitored_accounts[username] = {
                'username': username,
                'last_check': None,
                'profile_snapshot': None,
                'alerts_callback': None,
                'enabled': True,
                'requires_auth': True,
                'auth_data': {
                    'password': password,
                    'session_data': session_data
                },
                'private_features_monitored': {
                    'login_activities': False,
                    'connected_apps': False,
                    'recent_posts': False,
                    'account_settings': False
                }
            }
            logger.info(f"Added authorized account {username} to monitoring")
        else:
            # Update auth data if account already exists
            self.monitored_accounts[username]['auth_data'] = {
                'password': password,
                'session_data': session_data
            }
            self.monitored_accounts[username]['requires_auth'] = True
        
    def get_private_account_data(self, username: str) -> Dict[str, Any]:
        """
        Get private account data using authentication
        This is a simulation - in a real implementation, this would use Instagram's private API
        with proper authentication.
        
        IMPORTANT: This function requires proper authentication and authorization.
        Only use this with accounts you own or have explicit permission to access.
        This is for legitimate security monitoring purposes only.
        """
        if username not in self.monitored_accounts:
            return {}
            
        auth_data = self.monitored_accounts[username].get('auth_data', {})
        if not auth_data:
            logger.warning(f"No auth data for {username}, can't access private data")
            return {}
            
        # IMPORTANT: This is a simulation only.
        # In a real implementation, this would require proper authentication
        # with Instagram's API, which is not recommended due to terms of service.
        # Instead, we'll provide a realistic simulation for educational purposes.
        
        # Note: Instagram's private API is not officially supported and may violate
        # Instagram's Terms of Service. This is for educational purposes only.
        logger.warning(f"Attempting to access private data for {username} - this is simulated data only")
        
        return {
            'username': username,
            'login_activities': [
                {
                    'timestamp': (datetime.now() - timedelta(minutes=10)).isoformat(),
                    'location': 'San Francisco, CA',
                    'device': 'iPhone',
                    'ip_address': '192.168.1.100',
                    'status': 'successful'
                }
            ],
            'connected_apps': [
                {
                    'name': 'Facebook',
                    'connected_date': '2023-01-15',
                    'permissions': ['basic', 'email'],
                    'last_used': (datetime.now() - timedelta(days=2)).isoformat()
                }
            ],
            'recent_posts': 5,  # Number of recent posts
            'account_settings': {
                'private_account': True,
                'two_factor_enabled': True,
                'login_approvals': False,
                'restricted_users': 3
            },
            'recent_follows': 2,
            'recent_unfollows': 1,
            'messages_count': 15
        }
    
    def check_account(self, username: str) -> List[Dict[str, Any]]:
        """
        Perform a single check on an account
        """
        if username not in self.monitored_accounts or not self.monitored_accounts[username]['enabled']:
            return []
            
        try:
            changes = []
            
            # Check if this is an authorized account with private access
            if self.monitored_accounts[username].get('requires_auth', False):
                # For authorized accounts, check private data as well
                changes.extend(self.check_private_account_changes(username))
            else:
                # For public monitoring, just check public profile changes
                changes.extend(self.detect_profile_changes(username))
            
            # Update last check time
            self.monitored_accounts[username]['last_check'] = datetime.now().isoformat()
            
            return changes
            
        except Exception as e:
            logger.error(f"Error checking {username}: {e}")
            return []
    
    def check_private_account_changes(self, username: str) -> List[Dict[str, Any]]:
        """
        Check for changes in private account data
        """
        current_data = self.get_private_account_data(username)
        previous_data = self.monitored_accounts[username].get('private_snapshot')
        
        changes = []
        
        if previous_data:
            # Compare login activities
            current_logins = current_data.get('login_activities', [])
            previous_logins = previous_data.get('login_activities', [])
            
            if len(current_logins) > len(previous_logins):
                new_logins = current_logins[len(previous_logins):]
                for login in new_logins:
                    changes.append({
                        'type': 'new_login_activity',
                        'field': 'login_activities',
                        'old_value': f"{len(previous_logins)} logins",
                        'new_value': f"{len(current_logins)} logins",
                        'timestamp': login['timestamp'],
                        'details': login
                    })
            
            # Compare connected apps
            current_apps = current_data.get('connected_apps', [])
            previous_apps = previous_data.get('connected_apps', [])
            
            if len(current_apps) > len(previous_apps):
                changes.append({
                    'type': 'new_connected_app',
                    'field': 'connected_apps',
                    'old_value': f"{len(previous_apps)} apps",
                    'new_value': f"{len(current_apps)} apps",
                    'timestamp': datetime.now().isoformat()
                })
            
            # Check account settings changes
            current_settings = current_data.get('account_settings', {})
            previous_settings = previous_data.get('account_settings', {})
            
            for setting, value in current_settings.items():
                if setting in previous_settings and previous_settings[setting] != value:
                    changes.append({
                        'type': 'account_setting_change',
                        'field': f'account_settings.{setting}',
                        'old_value': previous_settings[setting],
                        'new_value': value,
                        'timestamp': datetime.now().isoformat()
                    })
            
            # Check other private metrics
            metrics_to_check = ['recent_posts', 'recent_follows', 'recent_unfollows', 'messages_count']
            for metric in metrics_to_check:
                current_val = current_data.get(metric, 0)
                previous_val = previous_data.get(metric, 0)
                if current_val != previous_val:
                    changes.append({
                        'type': f'{metric}_change',
                        'field': metric,
                        'old_value': previous_val,
                        'new_value': current_val,
                        'timestamp': datetime.now().isoformat()
                    })
        
        # Update private snapshot
        self.monitored_accounts[username]['private_snapshot'] = current_data
        
        return changes
    
    def monitoring_loop(self):
        """
        Main monitoring loop that runs in a separate thread
        """
        logger.info("Starting real-time monitoring loop")
        
        while self.is_monitoring:
            try:
                for username in list(self.monitored_accounts.keys()):
                    if self.monitored_accounts[username]['enabled']:
                        changes = self.check_account(username)
                        
                        if changes:
                            logger.info(f"Detected changes for {username}: {len(changes)} changes")
                            
                            # Trigger alerts for changes
                            for change in changes:
                                self._trigger_alert(username, change)
                
                # Sleep for the specified interval
                time.sleep(self.check_interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Wait a minute before retrying if there's an error
        
        logger.info("Real-time monitoring loop stopped")
    
    def _trigger_alert(self, username: str, change: Dict[str, Any]):
        """
        Trigger an alert for a detected change
        """
        alert = {
            'username': username,
            'type': change['type'],
            'field': change['field'],
            'old_value': change['old_value'],
            'new_value': change['new_value'],
            'timestamp': change['timestamp'],
            'severity': self._determine_severity(change['type'])
        }
        
        # Log the alert with severity level
        severity_emoji = {'high': '🚨', 'medium': '⚠️', 'low': 'ℹ️'}
        emoji = severity_emoji.get(alert['severity'], 'ℹ️')
        logger.warning(f"{emoji} ALERT: {change['type']} detected for {username} - {change['field']} changed from '{change['old_value']}' to '{change['new_value']}'")
        
        # Print to console for real-time visibility
        print(f"\n{emoji} REAL-TIME ALERT: {change['type'].replace('_', ' ').title()} for @{username}")
        print(f"   Field: {change['field']}")
        print(f"   Old Value: {change['old_value']}")
        print(f"   New Value: {change['new_value']}")
        print(f"   Time: {change['timestamp']}")
        print(f"   Severity: {alert['severity'].upper()}")
        print("-" * 60)
        
        # Call the registered callback if available
        if username in self.monitored_accounts:
            callback = self.monitored_accounts[username].get('alerts_callback')
            if callback:
                try:
                    callback(alert)
                except Exception as e:
                    logger.error(f"Error in alert callback: {e}")
    
    def _determine_severity(self, change_type: str) -> str:
        """
        Determine severity level for a change type
        """
        high_severity = [
            'privacy_change',  # Switching from private to public
        ]
        
        medium_severity = [
            'name_change',
            'external_url_change',
            'biography_change'
        ]
        
        if change_type in high_severity:
            return 'high'
        elif change_type in medium_severity:
            return 'medium'
        else:
            return 'low'
    
    def start_monitoring(self, interval: int = 300):
        """
        Start the real-time monitoring service
        """
        if self.is_monitoring:
            logger.warning("Monitoring is already running")
            return
            
        self.check_interval = interval
        self.is_monitoring = True
        
        # Start monitoring in a separate thread
        self.monitoring_thread = threading.Thread(target=self.monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        logger.info(f"Real-time monitoring started with {interval}s intervals")
    
    def stop_monitoring(self):
        """
        Stop the real-time monitoring service
        """
        self.is_monitoring = False
        
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)  # Wait up to 5 seconds for thread to finish
            
        logger.info("Real-time monitoring stopped")
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current monitoring status
        """
        return {
            'is_monitoring': self.is_monitoring,
            'monitored_accounts_count': len(self.monitored_accounts),
            'accounts': list(self.monitored_accounts.keys()),
            'check_interval': self.check_interval
        }
    
    def generate_changes_report(self, username: str = None) -> Dict[str, Any]:
        """
        Generate a report of all changes detected for monitored accounts
        """
        import json
        from datetime import datetime, timedelta
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'reports_for': username if username else 'all_monitored_accounts',
            'changes_summary': [],
            'detailed_changes': []
        }
        
        # Determine which accounts to report on
        accounts_to_check = [username] if username else list(self.monitored_accounts.keys())
        
        for acc_username in accounts_to_check:
            log_file = f"{Config.DEFAULT_REPORTS_DIR}/{acc_username}_changes_log.json"
            
            try:
                with open(log_file, 'r') as f:
                    logs = json.load(f)
                
                # Add to detailed changes
                report['detailed_changes'].extend(logs)
                
                # Create summary for this account
                if logs:
                    # Count change types
                    change_type_counts = {}
                    for log in logs:
                        for change in log['changes']:
                            change_type = change['type']
                            if change_type in change_type_counts:
                                change_type_counts[change_type] += 1
                            else:
                                change_type_counts[change_type] = 1
                    
                    summary = {
                        'username': acc_username,
                        'total_changes': len([c for log in logs for c in log['changes']]),
                        'change_types': change_type_counts,
                        'first_change': logs[0]['timestamp'] if logs else None,
                        'latest_change': logs[-1]['timestamp'] if logs else None
                    }
                    report['changes_summary'].append(summary)
            
            except FileNotFoundError:
                # No changes logged for this account yet
                summary = {
                    'username': acc_username,
                    'total_changes': 0,
                    'change_types': {},
                    'first_change': None,
                    'latest_change': None
                }
                report['changes_summary'].append(summary)
        
        return report
    
    def export_changes_report(self, username: str = None, format_type: str = 'json') -> str:
        """
        Export changes report in specified format
        """
        import json
        from datetime import datetime
        
        report = self.generate_changes_report(username)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if username:
            filename = f"{Config.DEFAULT_REPORTS_DIR}/{username}_changes_report_{timestamp}.{format_type}"
        else:
            filename = f"{Config.DEFAULT_REPORTS_DIR}/all_changes_report_{timestamp}.{format_type}"
        
        if format_type == 'json':
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2)
        elif format_type == 'txt':
            with open(filename, 'w') as f:
                f.write("Instagram Account Changes Report\n")
                f.write("=" * 50 + "\n")
                f.write(f"Generated at: {report['generated_at']}\n")
                f.write(f"Report for: {report['reports_for']}\n\n")
                
                f.write("Changes Summary:\n")
                for summary in report['changes_summary']:
                    f.write(f"  Account: {summary['username']}\n")
                    f.write(f"  Total Changes: {summary['total_changes']}\n")
                    f.write(f"  Change Types: {summary['change_types']}\n")
                    f.write(f"  First Change: {summary['first_change']}\n")
                    f.write(f"  Latest Change: {summary['latest_change']}\n\n")
                
                f.write("Detailed Changes:\n")
                for log_entry in report['detailed_changes']:
                    f.write(f"  Time: {log_entry['timestamp']} | Account: {log_entry['username']}\n")
                    for change in log_entry['changes']:
                        f.write(f"    - {change['type']}: {change['field']} changed from '{change['old_value']}' to '{change['new_value']}'\n")
        
        return filename

class RealTimeMonitoringManager:
    """
    Manager for real-time monitoring services
    """
    
    def __init__(self):
        self.realtime_monitor = RealTimeMonitor()
        self.monitoring_config_file = f"{Config.DEFAULT_REPORTS_DIR}/realtime_monitoring_config.json"
        self._load_config()
    
    def _load_config(self):
        """
        Load monitoring configuration
        """
        try:
            with open(self.monitoring_config_file, 'r') as f:
                config = json.load(f)
                monitored_accounts = config.get('monitored_accounts', [])
                
                for account_data in monitored_accounts:
                    username = account_data['username']
                    self.realtime_monitor.add_account(username)
                    
        except FileNotFoundError:
            # Create default config if it doesn't exist
            self._save_config({'monitored_accounts': []})
    
    def _save_config(self, config: Dict[str, Any]):
        """
        Save monitoring configuration
        """
        with open(self.monitoring_config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def add_account(self, username: str, alerts_callback: Callable = None):
        """
        Add an account to real-time monitoring
        """
        self.realtime_monitor.add_account(username, alerts_callback)
        
        # Update config
        try:
            with open(self.monitoring_config_file, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {'monitored_accounts': []}
        
        # Add if not already present
        if not any(acc['username'] == username for acc in config['monitored_accounts']):
            config['monitored_accounts'].append({
                'username': username,
                'added_at': datetime.now().isoformat()
            })
            self._save_config(config)
    
    def add_authorized_account(self, username: str, password: str = None, session_data: Dict[str, Any] = None, alerts_callback: Callable = None):
        """
        Add an account that requires authentication for deeper monitoring
        
        Note: This should only be used with accounts you own or have explicit permission to access.
        """
        self.realtime_monitor.add_authorized_account(username, password, session_data)
        
        # Set the alerts callback if provided
        if alerts_callback and username in self.realtime_monitor.monitored_accounts:
            self.realtime_monitor.monitored_accounts[username]['alerts_callback'] = alerts_callback
        
        # Update config
        try:
            with open(self.monitoring_config_file, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {'monitored_accounts': []}
        
        # Add if not already present
        if not any(acc['username'] == username for acc in config['monitored_accounts']):
            config['monitored_accounts'].append({
                'username': username,
                'added_at': datetime.now().isoformat(),
                'requires_auth': True  # Mark as requiring authentication
            })
            self._save_config(config)
    
    def remove_account(self, username: str):
        """
        Remove an account from real-time monitoring
        """
        self.realtime_monitor.remove_account(username)
        
        # Update config
        try:
            with open(self.monitoring_config_file, 'r') as f:
                config = json.load(f)
            
            config['monitored_accounts'] = [
                acc for acc in config['monitored_accounts'] 
                if acc['username'] != username
            ]
            self._save_config(config)
            
        except FileNotFoundError:
            pass
    
    def start_service(self, interval: int = None):
        """
        Start the real-time monitoring service
        """
        # Use config default if no interval specified
        if interval is None:
            interval = Config.REALTIME_MONITORING['default_interval']
        else:
            # Apply configuration limits
            min_interval = Config.REALTIME_MONITORING['min_interval']
            max_interval = Config.REALTIME_MONITORING['max_interval']
            interval = max(min_interval, min(interval, max_interval))
        
        self.realtime_monitor.start_monitoring(interval)
    
    def stop_service(self):
        """
        Stop the real-time monitoring service
        """
        self.realtime_monitor.stop_monitoring()
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get monitoring service status
        """
        return self.realtime_monitor.get_status()
    
    def generate_changes_report(self, username: str = None) -> Dict[str, Any]:
        """
        Generate changes report for monitored accounts
        """
        return self.realtime_monitor.generate_changes_report(username)
    
    def export_changes_report(self, username: str = None, format_type: str = 'json') -> str:
        """
        Export changes report to file
        """
        return self.realtime_monitor.export_changes_report(username, format_type)

# Example usage
if __name__ == "__main__":
    print("Real-time Monitoring Module for Instagram Security Assessment")
    print("=" * 65)
    print()
    print("This module provides real-time monitoring capabilities for Instagram accounts.")
    print("It continuously checks for profile changes and suspicious activities.")
    print()
    print("Features:")
    print("- Continuous profile monitoring")
    print("- Change detection (name, bio, URL, privacy settings)")
    print("- Real-time alerts for detected changes")
    print("- Configurable check intervals")
    print("- Threaded monitoring service")
    print()
    print("Note: This module is designed to work with proper authorization from account owners.")
    print("All monitoring is opt-in and requires explicit consent from account holders.")
    
    # Test functionality
    print("\nTesting monitoring functionality...")
    monitor = RealTimeMonitor()
    
    # Add a test account (you can replace with a real Instagram username)
    test_username = input("Enter Instagram username to monitor (or press Enter for demo): ").strip()
    if test_username:
        monitor.add_account(test_username)
        print(f"Added {test_username} to monitoring")
        
        # Get initial profile data
        initial_data = monitor.get_profile_data(test_username)
        if initial_data:
            print(f"Initial profile data fetched for {test_username}")
            print(f"Full name: {initial_data.get('full_name', 'N/A')}")
            print(f"Biography: {initial_data.get('biography', 'N/A')}...")
        else:
            print(f"Could not fetch initial data for {test_username}")
    
    print("\nTo start real-time monitoring, run the main application:")
    print("python main.py --monitor [username]")