"""
Training module for Instagram Account Security Assessment Tool
Provides interactive awareness and training content explaining real-world compromise techniques
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any
import logging
from config import Config

logger = logging.getLogger(__name__)

class SecurityTrainingModule:
    """
    Provides interactive security training and awareness content
    """
    
    def __init__(self):
        self.training_modules = self._load_training_content()
        
    def _load_training_content(self) -> Dict[str, Any]:
        """
        Load security training content
        """
        return {
            'phishing_awareness': {
                'title': 'Phishing Awareness',
                'description': 'Learn to identify and prevent phishing attacks',
                'content': [
                    {
                        'topic': 'What is Phishing?',
                        'text': 'Phishing is a cyber attack that uses disguised email as a weapon. The perpetrator sends an email that appears to be from a trusted source, but is actually from a fraudster who wants to obtain personal information or install malware.',
                        'examples': [
                            'Fake emails from Instagram support asking for login details',
                            'Messages claiming account will be suspended unless immediate action is taken',
                            'Fake password reset emails with malicious links'
                        ]
                    },
                    {
                        'topic': 'How to Identify Phishing',
                        'text': 'Look for these red flags in suspicious messages:',
                        'indicators': [
                            'Urgent or threatening language',
                            'Generic greetings like "Dear User"',
                            'Suspicious email addresses',
                            'Unexpected attachments or links',
                            'Poor spelling and grammar'
                        ]
                    },
                    {
                        'topic': 'Protection Tips',
                        'text': 'Protect yourself from phishing attacks:',
                        'tips': [
                            'Verify the sender independently',
                            'Never enter credentials on suspicious websites',
                            'Use two-factor authentication',
                            'Keep software updated',
                            'Report suspicious messages to the platform'
                        ]
                    }
                ]
            },
            'password_security': {
                'title': 'Password Security Best Practices',
                'description': 'Learn how to create and manage strong passwords',
                'content': [
                    {
                        'topic': 'Creating Strong Passwords',
                        'text': 'A strong password is your first line of defense against unauthorized access.',
                        'guidelines': [
                            'Use at least 12 characters',
                            'Include uppercase, lowercase, numbers, and special characters',
                            'Avoid personal information',
                            'Don\'t reuse passwords across sites',
                            'Use unique passwords for each account'
                        ]
                    },
                    {
                        'topic': 'Password Managers',
                        'text': 'Password managers are tools that generate and store unique, complex passwords for all your accounts.',
                        'benefits': [
                            'Generate truly random passwords',
                            'Store passwords securely',
                            'Fill login forms automatically',
                            'Sync passwords across devices',
                            'Alert you to compromised passwords'
                        ]
                    },
                    {
                        'topic': 'Common Password Mistakes',
                        'text': 'Avoid these common password mistakes:',
                        'mistakes': [
                            'Using personal information (names, birthdates)',
                            'Reusing passwords across multiple sites',
                            'Using common passwords like "123456" or "password"',
                            'Writing passwords down on paper',
                            'Sharing passwords with others'
                        ]
                    }
                ]
            },
            'social_engineering': {
                'title': 'Social Engineering Defense',
                'description': 'Understanding and defending against social engineering attacks',
                'content': [
                    {
                        'topic': 'What is Social Engineering?',
                        'text': 'Social engineering is the practice of manipulating people into performing actions or divulging confidential information.',
                        'techniques': [
                            'Pretexting (creating a scenario to gain trust)',
                            'Baiting (offering something desirable to entice victim)',
                            'Quid pro quo (requesting compliance in exchange for something)',
                            'Tailgating (following someone into a restricted area)'
                        ]
                    },
                    {
                        'topic': 'OSINT and Social Engineering',
                        'text': 'Attackers often use Open Source Intelligence (OSINT) to gather information for social engineering:',
                        'information_types': [
                            'Personal details from social media profiles',
                            'Professional information from LinkedIn',
                            'Location data from geotagged posts',
                            'Relationship information from photos',
                            'Schedule information from posts about travel'
                        ]
                    },
                    {
                        'topic': 'Protection Strategies',
                        'text': 'Protect yourself from social engineering:',
                        'strategies': [
                            'Limit personal information in public profiles',
                            'Be cautious about sharing details online',
                            'Verify requests for information through independent channels',
                            'Be skeptical of urgent requests',
                            'Educate yourself about common tactics'
                        ]
                    }
                ]
            },
            '2fa_mfa_education': {
                'title': 'Two-Factor Authentication Education',
                'description': 'Understanding and implementing multi-factor authentication',
                'content': [
                    {
                        'topic': 'What is 2FA/MFA?',
                        'text': 'Two-Factor Authentication (2FA) or Multi-Factor Authentication (MFA) adds an extra layer of security beyond your password.',
                        'factors': [
                            'Something you know (password)',
                            'Something you have (phone, hardware token)',
                            'Something you are (biometrics)'
                        ]
                    },
                    {
                        'topic': 'Types of 2FA',
                        'text': 'Different methods of implementing two-factor authentication:',
                        'methods': [
                            'SMS codes (vulnerable to SIM swapping)',
                            'Authenticator apps (TOTP - Time-based One-Time Password)',
                            'Hardware security keys (most secure)',
                            'Email codes',
                            'Biometric authentication'
                        ]
                    },
                    {
                        'topic': 'Best Practices for 2FA',
                        'text': 'Maximize security with these 2FA practices:',
                        'best_practices': [
                            'Use authenticator apps over SMS when possible',
                            'Set up backup authentication methods',
                            'Store backup codes securely',
                            'Use hardware security keys for critical accounts',
                            'Don\'t share authentication devices'
                        ]
                    }
                ]
            },
            'account_recovery': {
                'title': 'Secure Account Recovery',
                'description': 'Setting up and maintaining secure account recovery options',
                'content': [
                    {
                        'topic': 'Recovery Method Security',
                        'text': 'Account recovery methods can be targeted by attackers:',
                        'vulnerabilities': [
                            'Recovery emails can be compromised',
                            'Phone numbers susceptible to SIM swapping',
                            'Recovery questions may be guessable',
                            'Trusted contacts might be manipulated'
                        ]
                    },
                    {
                        'topic': 'Secure Recovery Setup',
                        'text': 'Configure account recovery securely:',
                        'setup_tips': [
                            'Use a dedicated recovery email',
                            'Enable multiple recovery methods',
                            'Keep recovery information current',
                            'Use unique, hard-to-guess recovery questions',
                            'Regularly review recovery options'
                        ]
                    },
                    {
                        'topic': 'Recovery Monitoring',
                        'text': 'Monitor your recovery methods:',
                        'monitoring_tips': [
                            'Watch for unauthorized changes to recovery info',
                            'Enable alerts for recovery attempts',
                            'Regularly test recovery methods',
                            'Secure recovery email and phone accounts',
                            'Have backup recovery options'
                        ]
                    }
                ]
            }
        }
    
    def get_module_content(self, module_name: str) -> Dict[str, Any]:
        """
        Get content for a specific training module
        """
        if module_name in self.training_modules:
            return self.training_modules[module_name]
        else:
            raise ValueError(f"Training module '{module_name}' not found")
    
    def list_available_modules(self) -> List[str]:
        """
        List all available training modules
        """
        return list(self.training_modules.keys())
    
    def get_quiz_for_module(self, module_name: str) -> List[Dict[str, Any]]:
        """
        Generate a quiz for a training module to test knowledge
        """
        quizzes = {
            'phishing_awareness': [
                {
                    'question': 'Which of these is NOT a common phishing indicator?',
                    'options': [
                        'Generic greeting like "Dear User"',
                        'Urgent language demanding immediate action',
                        'Personalized greeting with your name',
                        'Suspicious email address'
                    ],
                    'correct_answer': 2,  # Personalized greeting
                    'explanation': 'A personalized greeting with your name is NOT a phishing indicator. Phishing emails often use generic greetings because they don\'t know your name.'
                },
                {
                    'question': 'What should you do if you receive a suspicious email claiming to be from Instagram?',
                    'options': [
                        'Reply to the email with your account details',
                        'Click on any links to verify the issue',
                        'Verify independently through Instagram app/website',
                        'Forward the email to friends for their opinion'
                    ],
                    'correct_answer': 2,  # Verify independently
                    'explanation': 'Always verify suspicious communications through official channels like the Instagram app or website directly, not through links in suspicious emails.'
                }
            ],
            'password_security': [
                {
                    'question': 'What is the minimum recommended password length?',
                    'options': [
                        '6 characters',
                        '8 characters', 
                        '12 characters',
                        '16 characters'
                    ],
                    'correct_answer': 2,  # 12 characters
                    'explanation': 'Security experts recommend using at least 12 characters for passwords to provide adequate security against brute-force attacks.'
                },
                {
                    'question': 'What is a password manager?',
                    'options': [
                        'A person who manages your passwords',
                        'A tool that generates and stores unique passwords',
                        'A type of password',
                        'A security question'
                    ],
                    'correct_answer': 1,  # Tool that generates and stores
                    'explanation': 'A password manager is a tool that generates, stores, and fills unique, complex passwords for all your accounts securely.'
                }
            ],
            'social_engineering': [
                {
                    'question': 'What does OSINT stand for?',
                    'options': [
                        'Open Source Intelligence',
                        'Online Security Information',
                        'Operational Security Intelligence',
                        'Open Security Network'
                    ],
                    'correct_answer': 0,  # Open Source Intelligence
                    'explanation': 'OSINT stands for Open Source Intelligence, which refers to collecting information from publicly available sources.'
                },
                {
                    'question': 'Which personal detail is safest to share publicly?',
                    'options': [
                        'Full birthdate',
                        'Current city of residence',
                        'Hobbies and interests',
                        'Workplace information'
                    ],
                    'correct_answer': 2,  # Hobbies and interests
                    'explanation': 'General hobbies and interests are less likely to be used for targeted attacks compared to specific personal details like birthdates, location, or workplace.'
                }
            ]
        }
        
        if module_name in quizzes:
            return quizzes[module_name]
        else:
            # Return a generic quiz if module-specific quiz doesn't exist
            return [
                {
                    'question': f'What is the main topic of the {module_name.replace("_", " ").title()} module?',
                    'options': ['A security topic', 'A technical topic', 'A privacy topic', 'A general topic'],
                    'correct_answer': 0,
                    'explanation': f'The {module_name.replace("_", " ").title()} module covers important security concepts related to this area.'
                }
            ]
    
    def display_module(self, module_name: str):
        """
        Display training module content in a formatted way
        """
        try:
            module = self.get_module_content(module_name)
            print(f"\n{'='*60}")
            print(f"MODULE: {module['title']}")
            print(f"Description: {module['description']}")
            print(f"{'='*60}")
            
            for i, content in enumerate(module['content'], 1):
                print(f"\n{i}. {content['topic']}")
                print(f"   {content['text']}")
                
                # Display different content based on type
                if 'indicators' in content:
                    print("   Key indicators:")
                    for indicator in content['indicators']:
                        print(f"     • {indicator}")
                
                if 'tips' in content:
                    print("   Best practices:")
                    for tip in content['tips']:
                        print(f"     • {tip}")
                
                if 'guidelines' in content:
                    print("   Guidelines:")
                    for guideline in content['guidelines']:
                        print(f"     • {guideline}")
                
                if 'examples' in content:
                    print("   Examples:")
                    for example in content['examples']:
                        print(f"     • {example}")
                
                if 'methods' in content:
                    print("   Methods:")
                    for method in content['methods']:
                        print(f"     • {method}")
                
                if 'strategies' in content:
                    print("   Strategies:")
                    for strategy in content['strategies']:
                        print(f"     • {strategy}")
            
            print(f"\n{'='*60}")
            
        except ValueError as e:
            print(f"Error: {e}")
    
    def run_quiz(self, module_name: str):
        """
        Run a quiz for the specified module
        """
        quiz_questions = self.get_quiz_for_module(module_name)
        print(f"\nSecurity Training Quiz: {module_name.replace('_', ' ').title()}")
        print(f"{'='*50}")
        
        score = 0
        total = len(quiz_questions)
        
        for i, question_data in enumerate(quiz_questions, 1):
            print(f"\n{i}. {question_data['question']}")
            for j, option in enumerate(question_data['options']):
                print(f"   {j+1}. {option}")
            
            try:
                user_answer = int(input("\nYour answer (1-4): ")) - 1
                if user_answer == question_data['correct_answer']:
                    print("✓ Correct!")
                    score += 1
                else:
                    print("✗ Incorrect")
                    print(f"Explanation: {question_data['explanation']}")
            except ValueError:
                print("Invalid input. Please enter a number between 1 and 4.")
        
        print(f"\nQuiz Results: {score}/{total} correct")
        percentage = (score / total) * 100
        print(f"Score: {percentage:.1f}%")
        
        if percentage >= 80:
            print("Excellent! You have a strong understanding of this topic.")
        elif percentage >= 60:
            print("Good job! You have a decent understanding but could review some concepts.")
        else:
            print("Consider reviewing the training module to improve your knowledge.")

class TrainingManager:
    """
    Manages the training modules and user progress
    """
    
    def __init__(self):
        self.training_module = SecurityTrainingModule()
        self.user_progress_file = f"{Config.DEFAULT_REPORTS_DIR}/training_progress.json"
        self.load_user_progress()
    
    def load_user_progress(self):
        """
        Load user training progress
        """
        try:
            with open(self.user_progress_file, 'r') as f:
                self.user_progress = json.load(f)
        except FileNotFoundError:
            self.user_progress = {
                'completed_modules': [],
                'quiz_scores': {},
                'last_accessed': None
            }
    
    def save_user_progress(self):
        """
        Save user training progress
        """
        self.user_progress['last_accessed'] = datetime.now().isoformat()
        with open(self.user_progress_file, 'w') as f:
            json.dump(self.user_progress, f, indent=2)
    
    def mark_module_completed(self, module_name: str):
        """
        Mark a training module as completed
        """
        if module_name not in self.user_progress['completed_modules']:
            self.user_progress['completed_modules'].append(module_name)
            self.save_user_progress()
            print(f"Module '{module_name}' marked as completed!")
    
    def record_quiz_score(self, module_name: str, score: float):
        """
        Record quiz score for a module
        """
        if 'quiz_scores' not in self.user_progress:
            self.user_progress['quiz_scores'] = {}
        
        self.user_progress['quiz_scores'][module_name] = score
        self.save_user_progress()
        print(f"Quiz score for '{module_name}' recorded: {score}%")
    
    def get_user_progress(self) -> Dict[str, Any]:
        """
        Get user's training progress
        """
        return self.user_progress
    
    def display_progress(self):
        """
        Display user's training progress
        """
        progress = self.get_user_progress()
        print("\nTraining Progress Report")
        print("="*30)
        print(f"Modules completed: {len(progress['completed_modules'])}")
        print(f"Modules available: {len(self.training_module.list_available_modules())}")
        
        if progress['quiz_scores']:
            print("\nQuiz Scores:")
            for module, score in progress['quiz_scores'].items():
                print(f"  {module}: {score}%")
        
        print(f"\nLast accessed: {progress['last_accessed'] or 'Never'}")

# Example usage
if __name__ == "__main__":
    from datetime import datetime  # Import here since it's used in the TrainingManager
    
    print("Instagram Account Security Assessment - Training Module")
    print("=" * 60)
    print()
    print("This module provides interactive security awareness and training content.")
    print("It educates users about real-world compromise techniques and defense strategies.")
    print()
    print("Available training modules:")
    
    training = SecurityTrainingModule()
    for module in training.list_available_modules():
        print(f"  - {module.replace('_', ' ').title()}")
    
    print()
    print("The training module includes:")
    print("- Educational content on security topics")
    print("- Interactive quizzes to test knowledge")
    print("- Best practices and protection strategies")
    print("- Real-world examples of attacks and defenses")
    print()
    print("Note: This module is designed to improve security awareness and reduce risk.")