# Instagram Account Security Assessment Tool - Installation Troubleshooting Guide

## Common Installation Issues and Solutions

### 1. Python Not Found

**Error Message**: `Python is not installed or not in PATH`

**Solutions**:
- **Linux (Ubuntu/Debian)**: `sudo apt update && sudo apt install python3 python3-pip`
- **Linux (CentOS/RHEL)**: `sudo yum install python3 python3-pip` or `sudo dnf install python3 python3-pip`
- **Linux (Arch)**: `sudo pacman -S python python-pip`
- **macOS**: Install from https://python.org or use Homebrew: `brew install python`
- **Termux**: `pkg install python`
- **Windows**: Download from https://python.org (make sure to check "Add Python to PATH" during installation)

### 2. Pip Not Found

**Error Message**: `Pip is not available`

**Solutions**:
- Make sure you selected "Install pip" during Python installation
- On Linux: `sudo apt install python3-pip` (Ubuntu/Debian) or equivalent for your distro
- On Windows: Reinstall Python and ensure pip is selected during installation
- Try running `python -m ensurepip --upgrade` to install pip

### 3. Venv Module Not Available

**Error Message**: `Error: venv module is not available`

**Solutions**:
- **Linux (Ubuntu/Debian)**: `sudo apt install python3-venv`
- **Linux (CentOS/RHEL)**: `sudo yum install python3-venv`
- **Windows**: Make sure you have Python 3.3+ installed
- If still having issues, install without virtual environment: `pip install -r requirements.txt`

### 4. Permission Errors

**Error Message**: `PermissionError` or `Operation not permitted`

**Solutions**:
- **Linux/macOS**: Use `python -m pip install --user -r requirements.txt` to install to user directory
- **Windows**: Run Command Prompt or PowerShell as Administrator (not recommended for security)
- Better option: Use virtual environment (recommended approach)

### 5. Network/Internet Issues

**Error Message**: Connection timeout or SSL certificate errors

**Solutions**:
- Check your internet connection
- If behind a corporate firewall, configure pip with proxy: `pip install --proxy http://user:password@proxyserver:port -r requirements.txt`
- Try upgrading certificates: `pip install --upgrade certifi`
- Use alternative PyPI index: `pip install -r requirements.txt -i https://pypi.org/simple/`

### 6. Virtual Environment Creation Failures

**Error Message**: `Error: Failed to create virtual environment`

**Solutions**:
- Check if you have write permissions in the current directory
- Make sure you have enough disk space
- Try creating the virtual environment manually: `python -m venv venv`
- Ensure your antivirus isn't blocking Python operations

### 7. Package Installation Failures

**Error Message**: `Error installing requirements` or `Could not install packages`

**Solutions**:
- Try upgrading pip first: `python -m pip install --upgrade pip`
- Clear pip cache: `pip cache purge`
- Install packages individually: `pip install requests urllib3 certifi`
- Use different PyPI mirror: `pip install -r requirements.txt -i https://pypi.org/simple/`

## Platform-Specific Troubleshooting

### Windows Issues

1. **PowerShell Execution Policy**:
   - Error: `execution of scripts is disabled`
   - Solution: Run PowerShell as Administrator and execute: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

2. **Long Path Issues**:
   - Enable long path support in Windows 10/11:
     - Open Registry Editor (regedit)
     - Navigate to `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem`
     - Set `LongPathsEnabled` to 1

3. **Antivirus Interference**:
   - Add the tool directory to antivirus exclusions
   - Temporarily disable real-time protection during installation

### Linux Issues

1. **Missing Development Headers**:
   - Error during installation of packages that need compilation
   - Solution: `sudo apt install build-essential libssl-dev libffi-dev python3-dev` (Ubuntu/Debian)

2. **Wrong Python Version**:
   - Check version: `python3 --version`
   - Use specific version: `python3.8` or `python3.9` if available

### macOS Issues

1. **Xcode Command Line Tools**:
   - Install: `xcode-select --install`
   - Required for packages that need compilation

2. **Apple Silicon (M1/M2) Issues**:
   - Some packages may need to be installed with: `arch -arm64 pip install -r requirements.txt`

### Termux Issues

1. **Storage Access**:
   - Run: `termux-setup-storage`
   - This allows access to shared storage

2. **Missing Dependencies**:
   - Install: `pkg install clang python libcrypt libffi openssl`

## Manual Installation Steps

If the installation scripts fail, follow these manual steps:

### 1. Verify Python Installation
```bash
python3 --version
pip --version
```

### 2. Create Virtual Environment
```bash
python3 -m venv venv
```

### 3. Activate Virtual Environment
- **Linux/macOS/Termux**: `source venv/bin/activate`
- **Windows**: `venv\Scripts\activate`

### 4. Upgrade Pip
```bash
pip install --upgrade pip
```

### 5. Install Requirements
```bash
pip install -r requirements.txt
```

### 6. Verify Installation
```bash
python main.py --help
```

## Alternative Installation Methods

### Without Virtual Environment (Not Recommended)
```bash
pip install -r requirements.txt
```

### Using Conda/Mamba
```bash
conda create -n instagram-tool python=3.9
conda activate instagram-tool
pip install -r requirements.txt
```

## Running the Tool After Installation

### With Virtual Environment (Recommended)
```bash
# Activate environment
source venv/bin/activate  # Linux/macOS/Termux
venv\Scripts\activate     # Windows

# Run the tool
python main.py [username]

# Deactivate environment when done
deactivate
```

### Using Run Scripts
```bash
# Linux/macOS/Termux
./run.sh [username]

# Windows
run.bat [username]
```

## Getting Help

If you continue to experience installation issues:

1. Check that you're running the installation script from the correct directory
2. Ensure you have the latest version of the tool
3. Verify that your system meets the requirements
4. Check the error messages carefully for specific package issues
5. Try the manual installation steps above

## System Requirements

- **Python**: 3.7 or higher
- **RAM**: 512MB minimum, 1GB recommended
- **Disk Space**: 100MB minimum
- **Internet**: Required for initial installation and OSINT features
- **OS**: Linux, macOS, Windows 7+, or Termux

## Setup Verification

After installation, you can verify that everything is set up correctly by running:

```bash
python verify_setup.py
```

This script will check:
- Python version compatibility
- Pip availability
- Required packages installation
- Virtual environment status
- Directory structure
- Instagram connectivity
- Monitoring module functionality

## Security Notes

- The installation process only downloads packages from official PyPI repository
- Always verify the authenticity of the tool from the official source
- Use virtual environments to isolate dependencies
- Never run installation scripts from untrusted sources

For additional help, please check the project documentation or create an issue if you encounter persistent problems.