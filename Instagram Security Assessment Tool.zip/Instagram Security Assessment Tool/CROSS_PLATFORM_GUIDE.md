# Instagram Account Security Assessment Tool - Cross-Platform Guide

## Overview
This guide provides instructions for installing and running the Instagram Account Security Assessment Tool on multiple platforms: Linux, macOS, Windows, and Termux.

## Prerequisites

### All Platforms
- Python 3.7 or higher
- Internet connection for OSINT checks
- Git (optional, for cloning the repository)

### Platform-Specific Prerequisites

#### Linux
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv git

# CentOS/RHEL/Fedora
sudo yum install python3 python3-pip git
# or for newer versions:
sudo dnf install python3 python3-pip git

# Arch Linux
sudo pacman -S python python python-pip git
```

#### macOS
```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python
brew install python3 git
```

#### Windows
- Download and install Python from https://python.org
- Make sure to check "Add Python to PATH" during installation
- Or install via Microsoft Store

#### Termux (Android)
```bash
pkg update
pkg install python git
```

## Installation Methods

### Method 1: Using Setup Script (Recommended)

#### Linux/macOS/Termux
```bash
# Make the script executable
chmod +x setup.py

# Run the setup
python3 setup.py
```

#### Windows
```cmd
python setup.py
```

### Method 2: Manual Installation

#### All Platforms
```bash
# Clone the repository (if not already done)
git clone <repository-url>
cd instagram-security-assessment

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Linux/macOS/Termux:
source venv/bin/activate

# On Windows:
# Command Prompt:
venv\Scripts\activate
# PowerShell:
venv\Scripts\Activate.ps1

# Upgrade pip
pip install --upgrade pip

# Install requirements
pip install -r requirements.txt
```

### Method 3: Platform-Specific Scripts

#### Linux/macOS/Termux
```bash
chmod +x install.sh
./install.sh
```

#### Windows
```cmd
install.bat
```

## Running the Tool

### Using Virtual Environment (Recommended)

#### Linux/macOS/Termux
```bash
# Activate virtual environment
source venv/bin/activate

# Run the tool
python main.py [username]

# Or use the run script
./run.sh [username]

# Deactivate when done
deactivate
```

#### Windows
```cmd
# Activate virtual environment
venv\Scripts\activate

# Run the tool
python main.py [username]

# Or use the run script
run.bat [username]

# Deactivate when done
deactivate
```

### Direct Execution
```bash
python main.py [username] --format [json/txt]
```

## Platform-Specific Notes

### Linux
- Most stable platform for the tool
- Supports all features without limitations
- Recommended for production use
- May require `sudo` for system-wide installations

### macOS
- Full feature support
- May need to allow Python in Security & Privacy settings
- Terminal access required for command-line operations
- Some network restrictions may apply

### Windows
- Full feature support
- PowerShell or Command Prompt required
- Antivirus software may flag network requests (add to exceptions if needed)
- Path limitations may apply on older systems

### Termux (Android)
- Limited but functional version
- Network requests may be restricted by mobile carrier
- Storage limitations may apply
- Background processing may be limited
- Recommended for on-the-go assessments

## Troubleshooting

### Common Issues

#### Python Not Found
- Ensure Python is installed and in PATH
- Try `python3` instead of `python` on some systems
- Check installation with `python --version`

#### Permission Errors
- On Linux/macOS, you may need to use `chmod +x` on scripts
- On Windows, run as administrator if needed
- In Termux, ensure storage permissions are granted

#### Network Issues
- Check internet connection
- Corporate firewalls may block requests
- Some platforms have rate limiting
- Use VPN if region-restricted

#### Virtual Environment Issues
- Ensure venv module is available
- Try `python3 -m venv` if `python -m venv` fails
- Check disk space availability

### Platform-Specific Troubleshooting

#### Linux
```bash
# If you encounter permission issues
sudo chown -R $USER:$USER /path/to/tool
chmod +x *.sh
```

#### macOS
```bash
# If Python path issues occur
export PATH="/usr/local/bin:$PATH"
# or for Apple Silicon Macs
export PATH="/opt/homebrew/bin:$PATH"
```

#### Windows
- Run Command Prompt or PowerShell as Administrator
- Check Windows Defender or other security software
- Ensure Windows is up to date

#### Termux
```bash
# Update packages
pkg update && pkg upgrade

# If storage access is needed
termux-setup-storage
```

## Performance Considerations

### Linux
- Best performance and stability
- Can handle multiple concurrent assessments
- Recommended for bulk operations

### macOS
- Good performance
- Background processing works well
- May have slightly slower network operations

### Windows
- Good performance
- Background processing may be limited
- Antivirus scanning may slow operations

### Termux
- Limited performance
- Network operations may be slower
- Background processing heavily restricted
- Battery optimization may affect long-running assessments

## Security and Privacy

### All Platforms
- Tool only accesses public information
- No login credentials required
- All data stays local to your device
- Network requests are logged for transparency

### Platform-Specific Considerations
- Linux: Most secure environment
- macOS: Good security with proper configuration
- Windows: Ensure security software doesn't interfere
- Termux: Android security model applies

## Updates

To update the tool on any platform:
```bash
# If using git
git pull origin main

# Update requirements
pip install --upgrade -r requirements.txt
```

## Uninstallation

### To remove the tool completely:
1. Delete the entire tool directory
2. Remove virtual environment if created: `rm -rf venv` (Linux/macOS/Termux) or `rmdir /s venv` (Windows)
3. Clear any configuration files in the reports directory if desired

## Support

For platform-specific issues:
- Linux/macOS/Termux: Check terminal output and logs
- Windows: Check Command Prompt/PowerShell output
- Termux: Check Termux logs with `logcat`

Remember to always use the tool ethically and with proper authorization!