# Instagram Account Security Assessment Tool

A professional, ethical tool for performing non-intrusive OSINT-based reconnaissance on publicly available Instagram profile data, analyzing security posture, and providing hardening recommendations.

## 🌟 Key Features

### 📊 Security Analysis
- **Public Profile Analysis**: Analyzes publicly available Instagram profile data for potential security risks
- **Username Reuse Assessment**: Checks for username reuse across 13+ platforms with risk weighting
- **Email/Domain Risk Analysis**: Identifies potential email and domain risks
- **Metadata Analysis**: Examines profile metadata for additional exposure points
- **Follower/Following Analysis**: Identifies unusual patterns that may indicate fake accounts

### 🔐 Authentication Assessment
- **Password Hygiene Simulation**: Provides guidance on password security (offline simulation)
- **2FA/MFA Assessment**: Evaluates multi-factor authentication best practices
- **Recovery Flow Risk**: Assesses account recovery vulnerabilities
- **Third-Party OAuth Exposure**: Evaluates connected applications

### 🛡️ Attack Simulation
- **Phishing Susceptibility**: Simulates potential phishing risks based on public information
- **Credential Stuffing Risk**: Assesses risks related to credential stuffing attacks
- **Brute-Force Protection**: Evaluates account protection mechanisms
- **Session Hijacking Awareness**: Provides education on session security

### 📈 Reporting & Recommendations
- **Security Score**: Generates a comprehensive security score (0-100) with detailed breakdowns
- **Step-by-Step Recommendations**: Provides actionable security hardening guidance
- **Exportable Reports**: Generates detailed reports in JSON or text format
- **Risk Categorization**: Organizes risks by category for targeted remediation

### 🎓 Educational Modules
- **Interactive Training**: Awareness modules explaining real-world compromise techniques
- **Phishing Education**: Detailed phishing awareness content
- **Password Security Training**: Best practices for password management
- **Social Engineering Defense**: Protection against social engineering attacks

### 📡 Real-time Monitoring Features

The tool includes comprehensive real-time monitoring capabilities that can:

- **Monitor Profile Changes**: Track changes to username, full name, bio, external URL, privacy settings, and post count
- **Detect Suspicious Activities**: Identify unusual login patterns, new app connections, and other security events
- **Provide Real-time Alerts**: Generate immediate notifications when changes are detected
- **Generate Detailed Reports**: Create comprehensive reports of all changes with timestamps
- **Support Multiple Accounts**: Monitor multiple Instagram accounts simultaneously

### Real-time Monitoring Architecture

The real-time monitoring system includes:

1. **Profile Change Detection**: Monitors for changes in public profile information
2. **Activity Monitoring**: Tracks login activities and connected applications
3. **Alert System**: Generates alerts with severity levels (high, medium, low)
4. **Data Persistence**: Logs all changes to JSON files for historical analysis
5. **Configurable Intervals**: Allows setting custom monitoring intervals

### Setting Up Real-time Monitoring

Once Python is installed, you can use the real-time monitoring features:

1. **Through Interactive Mode**:
   ```bash
   python main.py
   # Select option 4: Real-time Monitoring Setup
   ```

2. **Direct Testing**:
   ```bash
   python test_monitoring.py
   ```

### Monitoring Configuration

The monitoring system uses configurable settings:
- Default check interval: 5 minutes (300 seconds)
- Minimum interval: 1 minute (60 seconds) 
- Maximum interval: 1 hour (3600 seconds)
- Maximum monitored accounts: 10
- Profile check timeout: 10 seconds

### Security and Privacy

- All monitoring is opt-in and requires explicit consent
- Only publicly available information is accessed
- No unauthorized access or actual attacks are performed
- Data is stored locally and not transmitted anywhere
- Authentication is required for private account monitoring (with user consent)

### Troubleshooting Real-time Monitoring

If real-time monitoring is not capturing changes:

1. **Verify Internet Connection**: Ensure stable connectivity for profile data fetching
2. **Check Instagram Availability**: Verify that Instagram is accessible in your region
3. **Review Rate Limits**: Instagram may apply rate limits; increase monitoring intervals if needed
4. **Validate Account Access**: Ensure the monitored accounts are public or you have proper access
5. **Check Logs**: Review log files in the reports directory for error messages

### Testing Real-time Monitoring

The tool includes a dedicated test script (`test_monitoring.py`) that provides:
- Basic monitoring functionality test
- Real-time monitoring test (30 seconds)
- Multiple account monitoring test
- Change detection verification

Additionally, there's a demonstration script (`demo_monitoring.py`) that showcases all monitoring capabilities:
```bash
python demo_monitoring.py
```

This allows you to verify that the monitoring system is properly detecting changes when Instagram profile information is modified.

### 📡 Monitoring & Alerts
- **User-Authorized Monitoring**: For account activity and suspicious logins
- **App Connection Tracking**: Monitors connected applications
- **Alert System**: Configurable alerts for security events
- **Real-Time Monitoring**: Continuous monitoring with configurable intervals
- **Profile Change Detection**: Monitors for changes in profile information
- **Private Account Monitoring**: Deeper monitoring for authorized accounts
- **Login Activity Tracking**: Monitors login activities and locations
- **Connected App Monitoring**: Tracks connected applications and permissions
- **Account Settings Monitoring**: Watches for changes in account settings
- **Automated Notifications**: Real-time alerts for detected changes
- **Change Reporting**: Detailed reports on all detected changes with timestamps
- **Exportable Reports**: JSON and TXT format reports for compliance and analysis

## 🌍 Cross-Platform Support

This tool is designed to work seamlessly across multiple platforms:

- ✅ **Linux**: Full feature support, recommended for production use
- ✅ **macOS**: Complete functionality with platform-specific optimizations
- ✅ **Windows**: Full compatibility with batch file automation
- ✅ **Termux**: Mobile security assessments on Android devices

## 🛠️ Requirements

### System Requirements
- Python 3.7 or higher
- Internet connection for OSINT checks
- 100MB free disk space

### Supported Platforms
- **Linux**: Ubuntu, Debian, CentOS, Fedora, Arch, and other distributions
- **macOS**: 10.14 (Mojave) or later
- **Windows**: 7, 8, 10, 11 (PowerShell or Command Prompt)
- **Termux**: Android 7.0 (API level 24) or later

### Python Dependencies
- `requests>=2.25.1`
- `urllib3>=1.26.0`
- `certifi>=2021.0.0`
- `charset-normalizer>=2.0.0`
- `idna>=3.0`

## 📦 Installation

### Method 1: Cross-Platform Setup Script (Recommended)

```bash
# Make executable and run setup
chmod +x setup.py  # Linux/macOS/Termux only
python setup.py
```

### Method 2: Platform-Specific Scripts

#### Linux/macOS/Termux:
```bash
chmod +x install.sh
./install.sh
```

#### Windows:
```cmd
install.bat
```

### Method 3: Manual Installation

```bash
# Clone or download this repository
# Install the required dependencies:
pip install -r requirements.txt
```

### Installation Troubleshooting

If you encounter issues during installation, please refer to our detailed troubleshooting guide: [INSTALLATION_TROUBLESHOOTING.md](INSTALLATION_TROUBLESHOOTING.md)

Common issues include:
- Python or pip not found in PATH
- Virtual environment creation failures
- Package installation errors
- Permission issues
- Network connectivity problems

The troubleshooting guide provides step-by-step solutions for these common issues across all platforms.

## 🚀 Usage

### Command Line Interface

Basic usage:
```bash
python main.py <instagram_username>
```

With specific output format:
```bash
python main.py <instagram_username> --format json
python main.py <instagram_username> --format txt
```

Direct execution of assessment:
```bash
python instagram_security_assessment.py <instagram_username>
```

### Interactive Mode
```bash
python main.py
```

Then follow the interactive menu for:
- Security assessments
- Training modules
- Monitoring setup
- Configuration viewing

### Real-time Monitoring Testing

To test the real-time monitoring functionality:

```bash
# Run the monitoring test script
python test_monitoring.py
```

The test script provides several options:
1. Basic monitoring functionality test
2. Real-time monitoring test (30 seconds)
3. Multiple account monitoring test
4. Run all tests

For real-time monitoring in the main application:
```bash
# Start interactive mode and select "Real-time Monitoring Setup"
python main.py
# Then choose option 4 from the main menu
```

### Running with Scripts

#### Linux/macOS/Termux:
```bash
./run.sh <instagram_username>
```

#### Windows:
```cmd
run.bat <instagram_username>
```

## ⚠️ Important Disclaimers

⚠️ **ETHICAL USE ONLY**: This tool is designed for ethical, authorized security assessments only.

⚠️ **NO UNAUTHORIZED ACCESS**: This tool does not perform actual attacks or gain unauthorized access to accounts.

⚠️ **RESPECT PRIVACY**: Only use this tool on accounts where you have explicit permission or on your own accounts.

⚠️ **COMPLIANCE**: Ensure your use complies with applicable laws and Instagram's Terms of Service.

⚠️ **EDUCATIONAL PURPOSES**: This tool is intended for educational, bug bounty preparation, and defensive security testing.

## 🔍 How It Works

The tool performs analysis using only publicly available information and simulated checks:

1. **Public Data Analysis**: Gathers and analyzes publicly available profile information
2. **OSINT Techniques**: Performs open-source intelligence gathering on username reuse
3. **Risk Simulation**: Simulates potential attack vectors using logic-based models
4. **Security Assessment**: Evaluates security posture based on gathered information
5. **Recommendation Engine**: Provides actionable security recommendations
6. **Training Modules**: Educates users about security concepts

## 📊 Security Score

The tool generates a detailed security score from 0-100 with breakdown:

- **90-100**: Excellent - Minimal security risks identified
- **75-89**: Good - Few minor security concerns
- **60-74**: Fair - Several security risks to address
- **40-59**: Poor - Significant security improvements needed
- **0-39**: Critical - Urgent security hardening required

### Risk Categories
- **Profile Privacy**: Exposure of personal information
- **Authentication**: 2FA, password security
- **Social Engineering**: Phishing susceptibility
- **Account Recovery**: Recovery method security
- **Data Exposure**: Information leakage risks

## 🛡️ Privacy & Compliance

### Ethical Standards
- Only uses publicly available information
- No unauthorized access or actual attacks
- Clear consent requirements for monitoring
- Data minimization principles applied

### Legal Compliance
- Designed with privacy in mind
- Compliant with responsible use practices
- Educational focus over exploitation
- Respectful of platform terms of service

## 📚 Additional Resources

- [Cross-Platform Guide](CROSS_PLATFORM_GUIDE.md): Complete platform-specific instructions
- [Project Summary](PROJECT_SUMMARY.md): Detailed feature overview
- [Real-time Monitoring Guide](REALTIME_MONITORING_GUIDE.md): Comprehensive guide for real-time monitoring features
- Training modules built into the tool

## 📞 Support

For support, please:
1. Check the [Cross-Platform Guide](CROSS_PLATFORM_GUIDE.md) first
2. Review error messages and logs
3. Ensure you're using the tool ethically and legally

## 📄 Legal Notice

This tool is provided for educational and ethical security assessment purposes. The authors are not responsible for any misuse of this tool. Always ensure you have proper authorization before conducting any security assessments on accounts you do not own. Use responsibly and in compliance with applicable laws.

## 🤝 Contributing

Contributions to improve the tool's functionality, accuracy, and ethical compliance are welcome. Please follow responsible disclosure practices and ethical guidelines when contributing.

## 📄 License

This project is provided as-is for educational purposes.