"""
Configuration settings for Instagram Account Security Assessment Tool
"""

import os
from datetime import datetime

class Config:
    """Configuration class for the Instagram Security Assessment Tool"""
    
    # Tool metadata
    TOOL_NAME = "Instagram Account Security Assessment Tool"
    VERSION = "1.0.0"
    AUTHOR = "Security Assessment Team"
    
    # Default settings
    DEFAULT_OUTPUT_FORMAT = "json"
    DEFAULT_REPORTS_DIR = "reports"
    DEFAULT_TIMEOUT = 10  # seconds for HTTP requests
    DEFAULT_RATE_LIMIT_DELAY = 1  # seconds between requests to be respectful
    
    # Security scoring weights (out of 100 total points)
    SCORE_WEIGHTS = {
        'profile_privacy': 20,
        'authentication': 25, 
        'osint_exposure': 20,
        'recovery_options': 15,
        'monitoring': 10,
        'education': 10
    }
    
    # Risk levels
    RISK_LEVELS = {
        'critical': {'score_impact': -25, 'color': 'red'},
        'high': {'score_impact': -15, 'color': 'orange'},
        'medium': {'score_impact': -8, 'color': 'yellow'},
        'low': {'score_impact': -3, 'color': 'lightyellow'}
    }
    
    # Supported output formats
    SUPPORTED_FORMATS = ['json', 'txt']
    
    # OSINT platforms to check for username reuse
    OSINT_PLATFORMS = [
        {'name': 'twitter', 'url_template': 'https://twitter.com/{}', 'weight': 0.8},
        {'name': 'github', 'url_template': 'https://github.com/{}', 'weight': 0.9},
        {'name': 'reddit', 'url_template': 'https://reddit.com/user/{}', 'weight': 0.7},
        {'name': 'tiktok', 'url_template': 'https://tiktok.com/@{}', 'weight': 0.6},
        {'name': 'youtube', 'url_template': 'https://youtube.com/user/{}', 'weight': 0.7},
        {'name': 'pinterest', 'url_template': 'https://pinterest.com/{}', 'weight': 0.5},
        {'name': 'snapchat', 'url_template': 'https://snapchat.com/add/{}', 'weight': 0.6},
        {'name': 'linkedin', 'url_template': 'https://linkedin.com/in/{}', 'weight': 0.9},
        {'name': 'tumblr', 'url_template': 'https://{}.tumblr.com', 'weight': 0.4},
        {'name': 'flickr', 'url_template': 'https://flickr.com/people/{}', 'weight': 0.4},
        {'name': 'deviantart', 'url_template': 'https://{}.deviantart.com', 'weight': 0.4},
        {'name': 'soundcloud', 'url_template': 'https://soundcloud.com/{}', 'weight': 0.5},
        {'name': 'medium', 'url_template': 'https://medium.com/@{}', 'weight': 0.5}
    ]
    
    # Common password patterns to warn about
    COMMON_PASSWORD_PATTERNS = [
        '{}123', '{}1', '{}2023', '{}2024', '{}!',
        'password', '123456', 'qwerty', 'abc123',
        'password123', 'welcome', 'admin', 'user'
    ]
    
    # Email domains to analyze
    COMMON_EMAIL_DOMAINS = [
        'gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com',
        'icloud.com', 'aol.com', 'protonmail.com', 'tutanota.com'
    ]
    
    # User agent for requests (be respectful)
    USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    
    # Legal and ethical guidelines
    ETHICAL_GUIDELINES = [
        "Only assess accounts you own or have explicit permission to assess",
        "Respect rate limits and robots.txt files",
        "Do not perform actual attacks or gain unauthorized access",
        "Comply with applicable laws and platform terms of service",
        "Use information responsibly and ethically",
        "Report findings appropriately"
    ]
    
    # Report generation settings
    REPORT_TEMPLATES = {
        'json': {
            'indent': 2,
            'ensure_ascii': False
        },
        'txt': {
            'section_separator': '=' * 60,
            'subsection_separator': '-' * 40
        }
    }
    
    # Real-time monitoring settings
    REALTIME_MONITORING = {
        'default_interval': 300,  # 5 minutes
        'min_interval': 60,      # 1 minute minimum
        'max_interval': 3600,    # 1 hour maximum
        'max_monitored_accounts': 10,  # Maximum accounts to monitor simultaneously
        'profile_check_timeout': 10,   # Timeout for profile checks
    }
    
    # Create reports directory if it doesn't exist
    @classmethod
    def setup_directories(cls):
        """Create necessary directories"""
        os.makedirs(cls.DEFAULT_REPORTS_DIR, exist_ok=True)
        
    # Initialize configuration
    @classmethod
    def initialize(cls):
        """Initialize configuration settings"""
        cls.setup_directories()
        
        # Log initialization
        print(f"{cls.TOOL_NAME} v{cls.VERSION} initialized")
        print(f"Reports directory: {cls.DEFAULT_REPORTS_DIR}")
        print(f"Supported formats: {', '.join(cls.SUPPORTED_FORMATS)}")

# Initialize the configuration when module is loaded
Config.initialize()