#!/usr/bin/env python3
"""
Test script for real-time monitoring functionality
"""

import sys
import os
import time
import threading
from datetime import datetime

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'modules'))

from modules.realtime_monitor import RealTimeMonitoringManager
from config import Config

def test_basic_monitoring():
    """
    Test basic monitoring functionality
    """
    print("Testing Basic Monitoring Functionality")
    print("=" * 40)
    
    # Create monitoring manager
    manager = RealTimeMonitoringManager()
    
    # Add a test account (replace with actual Instagram username for real testing)
    test_username = input("Enter Instagram username to test monitoring: ").strip()
    if not test_username:
        print("No username provided, using demo account 'instagram' for testing")
        test_username = 'instagram'
    
    # Add account to monitoring
    manager.add_account(test_username)
    print(f"Added {test_username} to monitoring")
    
    # Get initial profile data
    print(f"\nFetching initial profile data for {test_username}...")
    try:
        # Access the underlying monitor directly to get profile data
        monitor = manager.realtime_monitor
        initial_data = monitor.get_profile_data(test_username)
        
        if initial_data:
            print(f"✓ Successfully fetched profile data for {test_username}")
            print(f"  Full Name: {initial_data.get('full_name', 'N/A')}")
            print(f"  Biography: {initial_data.get('biography', 'N/A')[:50]}...")
            print(f"  Posts: {initial_data.get('posts_count', 'N/A')}")
            print(f"  Followers: {initial_data.get('followers_count', 'N/A')}")
        else:
            print(f"✗ Failed to fetch profile data for {test_username}")
            print("  This could be due to network issues, rate limiting, or private account")
    
    except Exception as e:
        print(f"✗ Error fetching profile data: {e}")
    
    # Test change detection
    print(f"\nTesting change detection...")
    try:
        changes = monitor.detect_profile_changes(test_username)
        print(f"  Detected changes: {len(changes)}")
        if changes:
            for change in changes:
                print(f"    - {change['type']}: {change['field']} changed at {change['timestamp']}")
    except Exception as e:
        print(f"✗ Error in change detection: {e}")
    
    print("\nBasic monitoring test completed.\n")


def test_realtime_monitoring():
    """
    Test real-time monitoring functionality
    """
    print("Testing Real-time Monitoring")
    print("=" * 30)
    
    # Create monitoring manager
    manager = RealTimeMonitoringManager()
    
    # Add a test account
    test_username = input("Enter Instagram username for real-time monitoring test: ").strip()
    if not test_username:
        print("No username provided, using demo account 'instagram' for testing")
        test_username = 'instagram'
    
    # Add account to real-time monitoring
    manager.add_account(test_username)
    print(f"Added {test_username} to real-time monitoring")
    
    # Define an alert callback to handle notifications
    def alert_callback(alert):
        print(f"\n🚨 ALERT: Change detected for {alert['username']}")
        print(f"   Type: {alert['type']}")
        print(f"   Field: {alert['field']}")
        print(f"   Old: {alert['old_value']}")
        print(f"   New: {alert['new_value']}")
        print(f"   Time: {alert['timestamp']}")
        print(f"   Severity: {alert['severity']}")
    
    # Set the callback for the account
    if test_username in manager.realtime_monitor.monitored_accounts:
        manager.realtime_monitor.monitored_accounts[test_username]['alerts_callback'] = alert_callback
    
    print(f"\nStarting real-time monitoring for {test_username}...")
    print("Monitoring will run for 30 seconds with 10-second intervals")
    print("Watch for changes in the Instagram account during this time!")
    print("Press Ctrl+C to stop early\n")
    
    try:
        # Start monitoring with short interval for testing
        manager.start_service(interval=10)  # Check every 10 seconds
        
        # Run for 30 seconds
        start_time = time.time()
        while time.time() - start_time < 30:
            time.sleep(1)
            # Check if monitoring is still active
            if not manager.realtime_monitor.is_monitoring:
                break
        
        print("\nStopping real-time monitoring...")
        manager.stop_service()
        
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped by user.")
        manager.stop_service()
    
    print("Real-time monitoring test completed.\n")


def test_multiple_accounts():
    """
    Test monitoring multiple accounts
    """
    print("Testing Multiple Account Monitoring")
    print("=" * 35)
    
    manager = RealTimeMonitoringManager()
    
    # Get multiple usernames
    usernames_input = input("Enter Instagram usernames separated by commas (or press Enter for demo): ").strip()
    if not usernames_input:
        print("Using demo accounts for testing")
        usernames = ['instagram', 'natgeo']  # Using well-known public accounts
    else:
        usernames = [u.strip() for u in usernames_input.split(',')]
    
    # Add all accounts to monitoring
    for username in usernames:
        if username:
            manager.add_account(username)
            print(f"Added {username} to monitoring")
    
    # Check initial data for all accounts
    print(f"\nChecking initial data for {len(usernames)} accounts...")
    for username in usernames:
        try:
            monitor = manager.realtime_monitor
            data = monitor.get_profile_data(username)
            if data:
                print(f"  ✓ {username}: {data.get('full_name', 'N/A')[:30]}...")
            else:
                print(f"  ✗ {username}: Failed to fetch data")
        except Exception as e:
            print(f"  ✗ {username}: Error - {e}")
    
    print("\nMultiple account monitoring test completed.\n")


def main():
    """
    Main test function
    """
    print("Instagram Account Security Assessment Tool - Monitoring Test")
    print("=" * 60)
    print("This script tests the real-time monitoring functionality")
    print("All tests are read-only and comply with Instagram's ToS")
    print("Only test with accounts you own or have permission to monitor")
    print("=" * 60)
    
    while True:
        print("\nMonitoring Test Options:")
        print("1. Test basic monitoring functionality")
        print("2. Test real-time monitoring (30s)")
        print("3. Test multiple account monitoring")
        print("4. Run all tests")
        print("5. Exit")
        
        choice = input("\nSelect an option (1-5): ").strip()
        
        if choice == '1':
            test_basic_monitoring()
        elif choice == '2':
            test_realtime_monitoring()
        elif choice == '3':
            test_multiple_accounts()
        elif choice == '4':
            test_basic_monitoring()
            test_realtime_monitoring()
            test_multiple_accounts()
        elif choice == '5':
            print("\nThank you for testing the monitoring functionality!")
            print("Remember to use this tool ethically and responsibly.")
            break
        else:
            print("Invalid choice. Please select 1-5.")


if __name__ == "__main__":
    main()