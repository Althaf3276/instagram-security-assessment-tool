#!/usr/bin/env python3
"""
Main entry point for Instagram Account Security Assessment Tool
"""

import sys
import os
import argparse
from datetime import datetime

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'modules'))

from instagram_security_assessment import InstagramSecurityAssessment
from modules.monitoring import MonitoringManager
from modules.training import TrainingManager
from modules.realtime_monitor import RealTimeMonitoringManager
from config import Config

def run_security_assessment(username, report_format='json'):
    """
    Run the main security assessment
    """
    print(f"Starting Instagram Account Security Assessment for: {username}")
    print("This tool performs ethical, non-intrusive analysis using only publicly available data.\n")
    
    assessment_tool = InstagramSecurityAssessment()
    
    if not assessment_tool.validate_username(username):
        print(f"Error: Invalid Instagram username format: {username}")
        print("Instagram usernames must be 3-30 characters and contain only letters, numbers, underscores, and periods.")
        return None
    
    try:
        # Perform the assessment
        profile_data = assessment_tool.analyze_profile_data(username)
        reuse_results = assessment_tool.assess_username_reuse(username)
        email_risks = assessment_tool.analyze_email_domain_risks(username)
        
        # Generate comprehensive report
        report = assessment_tool.generate_report(
            username, 
            profile_data, 
            reuse_results, 
            email_risks
        )
        
        # Save the report
        filepath = assessment_tool.save_report(report, report_format)
        
        # Display summary
        score = report['security_score']['score']
        level = report['security_score']['level']
        description = report['security_score']['description']
        risk_count = report['security_score']['risk_factors_count']
        priority = report['security_score']['recommendation_priority']
        
        print(f"Assessment Complete!")
        print(f"Security Score: {score}/100 ({level})")
        print(f"Description: {description}")
        print(f"Risk Factors: {risk_count}")
        print(f"Priority: {priority.replace('_', ' ').title()}")
        print(f"Report saved to: {filepath}")
        
        # Show security insights
        insights = report['security_score']['security_insights']
        print(f"\nSecurity Insights:")
        print(f"  Posture: {insights['overall_security_posture'].replace('_', ' ').title()}")
        print(f"  Primary Risks: {len(insights['primary_risk_factors'])}")
        print(f"  Strengths: {len(insights['security_strengths'])}")
        
        # Show top recommendations
        print(f"\nTop Security Recommendations:")
        for i, rec in enumerate(report['recommendations'][:3], 1):
            print(f"{i}. {rec['recommendation']}")
        
        print(f"\nFor full details, see the report: {filepath}")
        
        return report
        
    except Exception as e:
        print(f"An error occurred during assessment: {e}")
        import traceback
        traceback.print_exc()  # Print full traceback for debugging
        return None

def run_training_module():
    """
    Run the training module
    """
    print("Instagram Security Training Module")
    print("=" * 40)
    
    training_manager = TrainingManager()
    
    while True:
        print("\nTraining Options:")
        print("1. List available modules")
        print("2. View a module")
        print("3. Take a quiz")
        print("4. View progress")
        print("5. Back to main menu")
        
        choice = input("\nSelect an option (1-5): ").strip()
        
        if choice == '1':
            print("\nAvailable Training Modules:")
            training = training_manager.training_module
            for i, module in enumerate(training.list_available_modules(), 1):
                print(f"  {i}. {module.replace('_', ' ').title()}")
        
        elif choice == '2':
            module_name = input("\nEnter the module name to view: ").strip()
            try:
                training_manager.training_module.display_module(module_name)
                training_manager.mark_module_completed(module_name)
            except ValueError as e:
                print(f"Error: {e}")
        
        elif choice == '3':
            module_name = input("\nEnter the module name for the quiz: ").strip()
            try:
                training_manager.training_module.run_quiz(module_name)
                # Record the quiz score
                # Note: We'd need to modify run_quiz to return the score
                # For now, we'll just record a placeholder
                print("Quiz completed! Score recorded.")
            except ValueError as e:
                print(f"Error: {e}")
        
        elif choice == '4':
            training_manager.display_progress()
        
        elif choice == '5':
            break
        
        else:
            print("Invalid choice. Please select 1-5.")

def run_monitoring_setup():
    """
    Set up account monitoring
    """
    print("Instagram Account Monitoring Setup")
    print("=" * 35)
    
    monitor_manager = MonitoringManager()
    
    while True:
        print("\nMonitoring Options:")
        print("1. Add account to monitor")
        print("2. Remove account from monitoring")
        print("3. Check all monitored accounts")
        print("4. View monitoring report")
        print("5. View alerts")
        print("6. Real-time monitoring setup")
        print("7. Back to main menu")
        
        choice = input("\nSelect an option (1-7): ").strip()
        
        if choice == '1':
            username = input("\nEnter Instagram username to monitor: ").strip()
            if username:
                monitor = monitor_manager.add_monitor(username)
                print(f"Added {username} to monitoring.")
        
        elif choice == '2':
            username = input("\nEnter Instagram username to remove from monitoring: ").strip()
            if username:
                monitor_manager.remove_monitor(username)
                print(f"Removed {username} from monitoring.")
        
        elif choice == '3':
            suspicious = monitor_manager.check_all_monitors()
            if suspicious:
                print("\nSuspicious activities detected:")
                for username, activities in suspicious.items():
                    print(f"  {username}: {len(activities)} activities")
                    for activity in activities:
                        print(f"    - {activity['description']}")
            else:
                print("No suspicious activities detected.")
        
        elif choice == '4':
            username = input("\nEnter Instagram username to view monitoring report: ").strip()
            if username:
                report = monitor_manager.get_monitoring_report(username)
                if report:
                    print(f"\nMonitoring Report for {username}:")
                    for key, value in report.items():
                        print(f"  {key.replace('_', ' ').title()}: {value}")
                else:
                    print(f"No monitoring data for {username}")
        
        elif choice == '5':
            print("\nAlerts functionality would be implemented here.")
            print("This would show security alerts for monitored accounts.")
        
        elif choice == '6':
            run_realtime_monitoring_setup()
        
        elif choice == '7':
            break
        
        else:
            print("Invalid choice. Please select 1-7.")

def run_realtime_monitoring_setup():
    """
    Set up real-time monitoring
    """
    print("\nReal-time Monitoring Setup")
    print("=" * 30)
    
    realtime_manager = RealTimeMonitoringManager()
    
    while True:
        print("\nReal-time Monitoring Options:")
        print("1. Add account to real-time monitoring")
        print("2. Add authorized account (with credentials)")
        print("3. Remove account from real-time monitoring")
        print("4. Start real-time monitoring service")
        print("5. Stop real-time monitoring service")
        print("6. View monitoring status")
        print("7. Export changes report")
        print("8. Back to monitoring menu")
        
        choice = input("\nSelect an option (1-8): ").strip()
        
        if choice == '1':
            username = input("\nEnter Instagram username for real-time monitoring: ").strip()
            if username:
                realtime_manager.add_account(username)
                print(f"Added {username} to real-time monitoring.")
        
        elif choice == '2':
            username = input("\nEnter Instagram username for authorized monitoring: ").strip()
            if username:
                password = input("Enter password (will not be displayed): ")
                # In a real implementation, we would use getpass for secure password input
                realtime_manager.add_authorized_account(username, password)
                print(f"Added {username} to authorized real-time monitoring.")
        
        elif choice == '3':
            username = input("\nEnter Instagram username to remove from real-time monitoring: ").strip()
            if username:
                realtime_manager.remove_account(username)
                print(f"Removed {username} from real-time monitoring.")
        
        elif choice == '4':
            interval = input("\nEnter check interval in seconds (default 300): ").strip()
            try:
                interval = int(interval) if interval else 300
            except ValueError:
                interval = 300
            realtime_manager.start_service(interval)
            print(f"Real-time monitoring started with {interval}s intervals.")
        
        elif choice == '5':
            realtime_manager.stop_service()
            print("Real-time monitoring stopped.")
        
        elif choice == '6':
            status = realtime_manager.get_status()
            print(f"\nReal-time Monitoring Status:")
            print(f"  Active: {status['is_monitoring']}")
            print(f"  Accounts: {status['monitored_accounts_count']}")
            print(f"  Interval: {status['check_interval']}s")
            if status['accounts']:
                print(f"  Monitored: {', '.join(status['accounts'])}")
        
        elif choice == '7':
            # Generate and export reports
            username = input("\nEnter username for report (or press Enter for all accounts): ").strip()
            if username == "":
                username = None
            
            format_type = input("Enter report format (json/txt) [default: json]: ").strip().lower()
            if format_type not in ['json', 'txt']:
                format_type = 'json'
            
            try:
                filename = realtime_manager.export_changes_report(username, format_type)
                print(f"Report exported to: {filename}")
            except Exception as e:
                print(f"Error exporting report: {e}")
        
        elif choice == '8':
            break
        
        else:
            print("Invalid choice. Please select 1-8.")

def main():
    """
    Main function to run the Instagram Security Assessment Tool
    """
    parser = argparse.ArgumentParser(
        description="Instagram Account Security Assessment Tool - Ethical OSINT-based security analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("username", nargs='?', help="Instagram username to assess")
    parser.add_argument("--format", choices=['json', 'txt'], default='json', 
                       help="Output format for the report (default: json)")
    parser.add_argument("--output", help="Custom output filename (without extension)")
    
    args = parser.parse_args()
    
    print(f"Welcome to {Config.TOOL_NAME} v{Config.VERSION}")
    print("=" * 60)
    
    # If username provided as command line argument, run assessment directly
    if args.username:
        run_security_assessment(args.username, args.format)
        return
    
    # Otherwise, show interactive menu
    while True:
        print("\nMain Menu:")
        print("1. Run Security Assessment")
        print("2. Security Training Modules")
        print("3. Account Monitoring Setup")
        print("4. Real-time Monitoring Setup")
        print("5. View Configuration")
        print("6. Exit")
        
        choice = input("\nSelect an option (1-6): ").strip()
        
        if choice == '1':
            username = input("\nEnter Instagram username to assess: ").strip()
            if username:
                report_format = input("Enter report format (json/txt) [default: json]: ").strip().lower()
                if report_format not in ['json', 'txt']:
                    report_format = 'json'
                run_security_assessment(username, report_format)
            else:
                print("Username is required.")
        
        elif choice == '2':
            run_training_module()
        
        elif choice == '3':
            run_monitoring_setup()
        
        elif choice == '4':
            run_realtime_monitoring_setup()
        
        elif choice == '5':
            print(f"\n{Config.TOOL_NAME} Configuration:")
            print(f"  Version: {Config.VERSION}")
            print(f"  Reports Directory: {Config.DEFAULT_REPORTS_DIR}")
            print(f"  Default Format: {Config.DEFAULT_OUTPUT_FORMAT}")
            print(f"  Timeout: {Config.DEFAULT_TIMEOUT}s")
            print(f"  Rate Limit Delay: {Config.DEFAULT_RATE_LIMIT_DELAY}s")
            print(f"  Supported Formats: {', '.join(Config.SUPPORTED_FORMATS)}")
            print(f"  OSINT Platforms: {len(Config.OSINT_PLATFORMS)} configured")
        
        elif choice == '6':
            print("\nThank you for using the Instagram Account Security Assessment Tool.")
            print("Remember to use this tool ethically and responsibly.")
            print("Always ensure you have proper authorization before assessing accounts.")
            break
        
        else:
            print("Invalid choice. Please select 1-6.")

if __name__ == "__main__":
    main()