# Instagram Account Security Assessment Tool - Reporting Guide

## Overview

The reporting system provides comprehensive tracking and documentation of all publicly visible changes detected by the real-time monitoring system. This includes profile changes, account activities, and security-related events with detailed before/after information and timestamps.

**Important Security Note**: This system cannot and does not monitor private authentication details such as passwords or username changes that are not publicly visible. Instagram's security model does not allow third-party tools to access private account details like passwords. The system only monitors publicly visible profile information changes.

**Private Account Monitoring**: For authorized accounts where the user has explicit permission and credentials, the system can monitor additional private account data such as login activities, connected apps, account settings, and other private metrics. This requires the account owner's explicit consent and should only be used for legitimate security purposes.

## Reporting Features

### Change Tracking
- **Profile Changes**: Tracks modifications to name, bio, URL, privacy settings
- **Private Account Changes**: Monitors account settings, login activities, connected apps (for authorized accounts)
- **Timestamp Recording**: Captures exact time of each detected change
- **Before/After Values**: Records old and new values for each change
- **Change Type Classification**: Categorizes changes by type for analysis

### Report Generation
- **Summary Reports**: Overview of all changes with statistics
- **Detailed Reports**: Comprehensive logs with full change information
- **Multi-Account Reports**: Aggregated reports across multiple monitored accounts
- **Exportable Formats**: JSON and TXT format exports

### Data Retention
- **Log Rotation**: Automatic rotation to prevent excessive file growth
- **Historical Tracking**: Maintains change history for analysis
- **Efficient Storage**: Optimized storage to preserve system resources

## Report Structure

### Summary Report
The summary report provides an overview of all changes:

```
{
  "generated_at": "2023-12-07T10:30:45.123456",
  "reports_for": "username or all_monitored_accounts",
  "changes_summary": [
    {
      "username": "target_account",
      "total_changes": 5,
      "change_types": {
        "biography_change": 2,
        "name_change": 1,
        "external_url_change": 2
      },
      "first_change": "2023-12-07T09:15:22.123456",
      "latest_change": "2023-12-07T10:25:45.123456"
    }
  ],
  "detailed_changes": [...]
}
```

### Detailed Report
The detailed report includes complete information about each change:

```
{
  "timestamp": "2023-12-07T10:25:45.123456",
  "username": "target_account",
  "changes": [
    {
      "type": "biography_change",
      "field": "biography",
      "old_value": "Old bio description",
      "new_value": "New bio with updated information",
      "timestamp": "2023-12-07T10:25:45.123456"
    }
  ]
}
```

## Usage

### Through Main Interface

1. Run the main application:
```bash
python main.py
```

2. Select "Real-time Monitoring Setup" (option 4)

3. Select "Export changes report" (option 6)

4. Enter the username or press Enter for all accounts

5. Select report format (JSON or TXT)

### Direct Usage

```python
from modules.realtime_monitor import RealTimeMonitoringManager

# Create monitoring manager
monitor_manager = RealTimeMonitoringManager()

# Generate a report for a specific account
report = monitor_manager.generate_changes_report("target_username")

# Export a report
filename = monitor_manager.export_changes_report("target_username", "json")
print(f"Report exported to: {filename}")

# Export all monitored accounts report
filename = monitor_manager.export_changes_report(format_type="txt")
print(f"All accounts report exported to: {filename}")
```

### Demo Script

Run the demo to see reporting in action:

```bash
python reporting_demo.py
```

## Report Formats

### JSON Format
- Full structured data
- Suitable for programmatic processing
- Detailed change information
- Compatible with data analysis tools

### TXT Format
- Human-readable format
- Suitable for documentation
- Clear change descriptions
- Compatible with text editors

## Security and Privacy Considerations

### Data Protection
- All reports are stored locally
- No personal information is transmitted externally
- Reports contain only publicly observable changes
- Users have full control over report data

### Ethical Use
- Reports should only be generated for authorized accounts
- Data should be used for security purposes only
- Respect privacy of account owners
- Comply with applicable laws and regulations

## Integration with Monitoring

The reporting system integrates seamlessly with the real-time monitoring:

- Automatic change logging
- Scheduled report generation
- Alert-triggered reports
- Historical analysis capabilities

## Troubleshooting

### Common Issues

1. **Empty Reports**
   - Verify monitoring is active
   - Check that changes have occurred
   - Ensure account is properly monitored

2. **Missing Changes**
   - Verify check interval settings
   - Check monitoring service status
   - Review configuration settings

3. **Export Failures**
   - Check file permissions
   - Verify available disk space
   - Review file path validity

### Performance Tips

- Regularly review and archive old reports
- Use summary reports for quick overviews
- Export reports during low-usage periods
- Monitor disk space usage

## Legal and Ethical Guidelines

⚠️ **IMPORTANT**: Reports must only be used:

- On accounts you own or have explicit permission to monitor
- For defensive security purposes
- In compliance with applicable laws
- With respect to privacy rights

Never use reports for unauthorized surveillance or inappropriate purposes.

## Support

For reporting issues:
- Check the report generation logs
- Verify monitoring configuration
- Ensure sufficient disk space
- Review permission settings

Remember to always use this feature ethically and responsibly!