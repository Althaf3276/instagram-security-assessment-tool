#!/usr/bin/env python3
"""
Real-time monitoring demo for Instagram Account Security Assessment Tool
"""

import time
import threading
from datetime import datetime
from modules.realtime_monitor import RealTimeMonitoringManager

def alert_callback(alert):
    """
    Callback function to handle alerts
    """
    print(f"🚨 ALERT: {alert['type']} detected for {alert['username']}")
    print(f"   Field: {alert['field']}")
    print(f"   Old: {alert['old_value']}")
    print(f"   New: {alert['new_value']}")
    print(f"   Time: {alert['timestamp']}")
    print(f"   Severity: {alert['severity']}")
    print()

def main():
    """
    Main function to demonstrate real-time monitoring
    """
    print("Instagram Account Security Assessment Tool - Real-time Monitoring Demo")
    print("=" * 70)
    print()
    
    # Create monitoring manager
    monitor_manager = RealTimeMonitoringManager()
    
    print("Setting up real-time monitoring...")
    
    # Add a demo account to monitor
    monitor_manager.add_account("demo_user", alert_callback)
    print("Added 'demo_user' to real-time monitoring with alert callback")
    
    # Show initial status
    status = monitor_manager.get_status()
    print(f"Initial status: {status}")
    print()
    
    print("Starting real-time monitoring service (will run for 10 seconds for demo)...")
    monitor_manager.start_service(interval=5)  # Check every 5 seconds for demo
    
    # Let it run for a short time to demonstrate
    print("Monitoring running... (simulated changes will appear)")
    print("In a real implementation, this would detect actual Instagram profile changes")
    print()
    
    try:
        # Keep the main thread alive for the demo
        time.sleep(10)
    except KeyboardInterrupt:
        print("\nStopping monitoring...")
    
    # Stop the service
    monitor_manager.stop_service()
    print("Real-time monitoring stopped.")
    
    # Show final status
    status = monitor_manager.get_status()
    print(f"Final status: {status}")
    
    print("\nReal-time monitoring demo completed!")
    print("\nNote: This demo simulates real-time monitoring functionality.")
    print("In a real implementation, it would connect to Instagram's API or")
    print("use web scraping techniques to monitor actual profile changes.")

if __name__ == "__main__":
    main()