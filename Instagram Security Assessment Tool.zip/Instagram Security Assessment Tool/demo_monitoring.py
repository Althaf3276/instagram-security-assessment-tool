#!/usr/bin/env python3
"""
Demonstration script for Instagram Account Security Assessment Tool's real-time monitoring
This script demonstrates the real-time monitoring capabilities of the tool
"""

import sys
import os
import time
from datetime import datetime
import json

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'modules'))

from modules.realtime_monitor import RealTimeMonitoringManager
from config import Config

def demo_profile_change_detection():
    """
    Demonstrate profile change detection capabilities
    """
    print("🔍 DEMONSTRATION: Profile Change Detection")
    print("=" * 50)
    
    # Create monitoring manager
    manager = RealTimeMonitoringManager()
    
    # Demo with a well-known public account
    demo_username = 'instagram'  # Using a public account for demo
    
    print(f"Adding {demo_username} to monitoring...")
    manager.add_account(demo_username)
    
    print(f"\nFetching initial profile data for {demo_username}...")
    monitor = manager.realtime_monitor
    
    # Get initial data
    initial_data = monitor.get_profile_data(demo_username)
    if initial_data:
        print(f"✓ Initial data fetched successfully")
        print(f"  Username: {initial_data.get('username', 'N/A')}")
        print(f"  Full Name: {initial_data.get('full_name', 'N/A')}")
        print(f"  Biography: {initial_data.get('biography', 'N/A')[:60]}...")
        print(f"  Followers: {initial_data.get('followers_count', 'N/A'):,}")
        print(f"  Following: {initial_data.get('following_count', 'N/A'):,}")
        print(f"  Posts: {initial_data.get('posts_count', 'N/A'):,}")
        print(f"  Private: {initial_data.get('is_private', 'N/A')}")
        print(f"  Verified: {initial_data.get('is_verified', 'N/A')}")
    else:
        print(f"✗ Failed to fetch initial data for {demo_username}")
        print("  This may be due to network issues, rate limiting, or temporary unavailability")
        return
    
    # Store initial data to compare later
    print(f"\nStoring initial profile snapshot...")
    if demo_username in monitor.monitored_accounts:
        monitor.monitored_accounts[demo_username]['profile_snapshot'] = initial_data
    
    print(f"\nSimulating profile change detection...")
    # This would normally detect actual changes, but for demo we'll simulate
    time.sleep(1)  # Simulate time passing
    
    # Get updated data
    updated_data = monitor.get_profile_data(demo_username)
    if updated_data:
        # Detect changes
        changes = monitor.detect_profile_changes(demo_username)
        print(f"✓ Profile change detection completed")
        print(f"  Changes detected: {len(changes)}")
        
        if changes:
            print("  Change details:")
            for change in changes:
                print(f"    - {change['type'].replace('_', ' ').title()}: {change['field']} changed")
                print(f"      From: {change['old_value']}")
                print(f"      To: {change['new_value']}")
                print(f"      Time: {change['timestamp']}")
        else:
            print("  No changes detected (this is normal if no actual changes occurred)")
    else:
        print("✗ Failed to fetch updated data for change detection")
    
    print("\nProfile change detection demonstration completed.\n")


def demo_realtime_monitoring():
    """
    Demonstrate real-time monitoring capabilities
    """
    print("⏰ DEMONSTRATION: Real-time Monitoring")
    print("=" * 40)
    
    manager = RealTimeMonitoringManager()
    
    demo_username = 'natgeo'  # Using another public account for demo
    
    print(f"Setting up real-time monitoring for {demo_username}...")
    manager.add_account(demo_username)
    
    # Define a simple alert callback
    def demo_alert_callback(alert):
        print(f"\n🚨 ALERT: {alert['type'].replace('_', ' ').title()}")
        print(f"   User: {alert['username']}")
        print(f"   Field: {alert['field']}")
        print(f"   Old: {alert['old_value']}")
        print(f"   New: {alert['new_value']}")
        print(f"   Time: {alert['timestamp']}")
        print(f"   Severity: {alert['severity'].upper()}")
    
    # Set the callback
    if demo_username in manager.realtime_monitor.monitored_accounts:
        manager.realtime_monitor.monitored_accounts[demo_username]['alerts_callback'] = demo_alert_callback
    
    print(f"\nStarting real-time monitoring (short demo - 15 seconds)...")
    print("This will check for profile changes every 5 seconds")
    print("Press Ctrl+C to stop early\n")
    
    try:
        # Start monitoring with short intervals for demo
        manager.start_service(interval=5)  # Check every 5 seconds
        
        # Run for 15 seconds
        start_time = time.time()
        while time.time() - start_time < 15:
            time.sleep(1)
            if not manager.realtime_monitor.is_monitoring:
                break
        
        print("\nStopping real-time monitoring...")
        manager.stop_service()
        
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped by user.")
        manager.stop_service()
    
    print("Real-time monitoring demonstration completed.\n")


def demo_multiple_accounts():
    """
    Demonstrate monitoring multiple accounts
    """
    print("👥 DEMONSTRATION: Multiple Account Monitoring")
    print("=" * 45)
    
    manager = RealTimeMonitoringManager()
    
    # Demo with multiple well-known public accounts
    demo_accounts = ['instagram', 'natgeo', 'nasa']
    
    print("Adding multiple accounts to monitoring...")
    for username in demo_accounts:
        manager.add_account(username)
        print(f"  ✓ Added {username}")
    
    print(f"\nChecking initial data for {len(demo_accounts)} accounts...")
    for username in demo_accounts:
        try:
            monitor = manager.realtime_monitor
            data = monitor.get_profile_data(username)
            if data:
                print(f"  ✓ {username}: {data.get('full_name', 'N/A')[:30]}... ({data.get('followers_count', 0):,} followers)")
            else:
                print(f"  ✗ {username}: Failed to fetch data")
        except Exception as e:
            print(f"  ✗ {username}: Error - {str(e)[:50]}")
    
    print(f"\nCurrent monitoring status:")
    status = manager.get_status()
    print(f"  Monitoring Active: {status['is_monitoring']}")
    print(f"  Accounts Monitored: {status['monitored_accounts_count']}")
    print(f"  Check Interval: {status['check_interval']} seconds")
    if status['accounts']:
        print(f"  Monitored Accounts: {', '.join(status['accounts'])}")
    
    print("\nMultiple account monitoring demonstration completed.\n")


def demo_report_generation():
    """
    Demonstrate report generation capabilities
    """
    print("📊 DEMONSTRATION: Report Generation")
    print("=" * 35)
    
    manager = RealTimeMonitoringManager()
    
    # Add a demo account
    demo_username = 'instagram'
    manager.add_account(demo_username)
    
    print(f"Generating changes report for {demo_username}...")
    
    try:
        # Generate report
        report = manager.generate_changes_report(demo_username)
        print(f"✓ Report generated successfully")
        print(f"  Generated at: {report['generated_at']}")
        print(f"  Report for: {report['reports_for']}")
        print(f"  Summary entries: {len(report['changes_summary'])}")
        print(f"  Detailed entries: {len(report['detailed_changes'])}")
        
        # Show summary
        if report['changes_summary']:
            print("\nChanges Summary:")
            for summary in report['changes_summary']:
                print(f"  Account: {summary['username']}")
                print(f"    Total Changes: {summary['total_changes']}")
                print(f"    Change Types: {summary['change_types']}")
                print(f"    First Change: {summary['first_change']}")
                print(f"    Latest Change: {summary['latest_change']}")
        
        # Export report
        print(f"\nExporting report to file...")
        try:
            json_file = manager.export_changes_report(demo_username, 'json')
            print(f"✓ JSON report exported to: {json_file}")
            
            txt_file = manager.export_changes_report(demo_username, 'txt')
            print(f"✓ TXT report exported to: {txt_file}")
        except Exception as e:
            print(f"✗ Report export failed: {e}")
            
    except Exception as e:
        print(f"✗ Report generation failed: {e}")
        print("  This is normal if no changes have been detected yet")
    
    print("\nReport generation demonstration completed.\n")


def main():
    """
    Main demonstration function
    """
    print("🎮 Instagram Account Security Assessment Tool - Monitoring Demo")
    print("=" * 65)
    print("This demo showcases the real-time monitoring capabilities")
    print("All operations are read-only and respectful of Instagram's ToS")
    print("Only public information is accessed during these demonstrations")
    print("=" * 65)
    
    while True:
        print("\nDemo Options:")
        print("1. Profile Change Detection")
        print("2. Real-time Monitoring (15s demo)")
        print("3. Multiple Account Monitoring")
        print("4. Report Generation")
        print("5. Run All Demos")
        print("6. Exit Demo")
        
        choice = input("\nSelect an option (1-6): ").strip()
        
        if choice == '1':
            demo_profile_change_detection()
        elif choice == '2':
            demo_realtime_monitoring()
        elif choice == '3':
            demo_multiple_accounts()
        elif choice == '4':
            demo_report_generation()
        elif choice == '5':
            print("\n" + "="*50)
            print("RUNNING ALL DEMOS")
            print("="*50)
            demo_profile_change_detection()
            demo_realtime_monitoring()
            demo_multiple_accounts()
            demo_report_generation()
            print("All demos completed!")
        elif choice == '6':
            print("\nThank you for trying the Instagram Account Security Assessment Tool!")
            print("The real-time monitoring features are ready for actual use when you have Python installed.")
            print("Remember to use this tool ethically and responsibly.")
            break
        else:
            print("Invalid choice. Please select 1-6.")


if __name__ == "__main__":
    main()